<?php
    $conn=new mysqli("localhost", "d168_u168", "a123A123@&", "d168_db");
?>