<center>
<?php
echo "<h1>Hello</h1>";
?>
</center>