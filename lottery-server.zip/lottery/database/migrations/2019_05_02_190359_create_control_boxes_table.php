<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateControlBoxesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('control_boxes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('admin_id');
            $table->integer('A_status');
            $table->integer('B_status');
            $table->integer('C_status');
            $table->integer('D_status');
            $table->integer('H_status');
            $table->integer('I_status');
            $table->integer('N_status');
            $table->integer('l19_status');
            $table->integer('l22_status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('control_boxes');
    }
}
