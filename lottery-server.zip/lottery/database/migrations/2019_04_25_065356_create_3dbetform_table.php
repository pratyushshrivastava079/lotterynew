<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create3dbetformTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('3dbetform', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('user_id');
            $table->integer('d3_value');
            $table->double('usd_value');
            $table->integer('khr_value');
            $table->string('radio_value');
            $table->string('checkbox_value');
            $table->string('level_value');
            $table->string('level', 255);
            $table->string('batch'); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('3dbetform');
    }
}
