<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTotalSum extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('3dbetform', function (Blueprint $table) {
            //
             $table->char('total_sum', 255)->default('1');  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('3dbetform', function (Blueprint $table) {
            //
            $table->dropColumn('total_sum');
        });
    }
}
