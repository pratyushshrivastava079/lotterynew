         
        $(document).ready(function(){

            $('.fa-trash').click(function(){

                var userid = $(this).data('id');

                deleteuser(userid);

            });


        });



        function deleteuser(userid){

        console.log(userid);

            swal({
          title: "Warning",
          text: "Are you sure you want to delete this user",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
                $.ajax({

                    url: "<?php echo URL::to('/');?>/home/deleteuser",

                    headers: {
                    
                        'X-CSRF-TOKEN':'<?php echo csrf_token() ?>',
                
                    },

                    type: 'POST',

                    data: { 'userid': userid },

                    success:function(response){

                        console.log(response);
                    }

                });

          } else {
            // swal("Your imaginary file is safe!");
          }
        });

        }




