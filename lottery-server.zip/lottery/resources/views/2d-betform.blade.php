@extends('layouts.website')


@section('title')

Lottery | Dashboard | 2D Betform

@endsection

@section('content')

            <div class="card-header"><h2>Form</h2></div>

            <p>2D bet form for different level users.</p>

           @if(!isset($errors)) 
                {{ $errors }}

            @endif

            @if ($errors->any())
              
              <div class="alert alert-danger">
                
                <ul>
              
                  @foreach ($errors->all() as $error)
                
                    <li>{{ $error }}</li>
                
                  @endforeach
                
                </ul>
              
              </div>
          
            @endif

            @if(isset( $data ))

            <button class="btn btn-primary" id="pdf">Print</button>

              <table class="table table-hover table-respponsive" id="example">
              
                <thead>
              
                  <tr>
              
                    <th>2D</th>
              
                    <th>USD</th>
              
                    <th>KHR</th>
              
                    <th>PO</th>
              
                  </tr>
              
                </thead>
              
              <tbody>
              
  @php

                
                $datacount = count($data);


                if($datacount == 1){
              
              @endphp

               @foreach ($data as $bat)

                  <tr>
              
                    <td>{{ $bat->d2_value }}</td>
              
                    <td>{{ $bat->usd_value }}</td>
              
                    <td>{{ $bat->khr_value }}</td>

                    <td>@if(isset( $bat->checkbox_value ))

                      {{ $bat->checkbox_value }}

                      @elseif(isset( $bat->level_value ))

                      {{ $bat->level_value }}

                      @endif

                    </td>
                <td>{{ $bat->created_at}}</td>
              
                  </tr>
              @endforeach

              <tr>
                
                <td>Total</td>

                <td>

                  <?php $countcheckboxval = 0; $batval = 0;?>
                
                @foreach ($data as $bat)

                  @if(isset( $bat->radio_value ))

                    @if( $bat->radio_value == '5OD' || $bat->radio_value == '5S' )  
                     
                      @if(isset( $bat->checkbox_value )) 

                        $countcheckboxval = count($checkboxval);

                        $batval = $batval + $bat->usd_value;
                      
                        {{ $countcheckboxval * $batval * 5}}
                    
                      @if($bat->level_value == 'l23' )

                        {{$bat->usd_value * 5 * 23}}

                      @elseif( $bat->level_value == 'l29' )
                      
                        {{$bat->usd_value * 5 * 29}}

                      @endif

                    @endif

                    @elseif( $bat->radio_value == '10S' )

                      @if(isset( $bat->checkbox_value )) 

                        {{ count($checkboxvalue) * $bat->usd_value * 10}}

                    @endif

                  @endif

                  @elseif(isset( $bat->level_value ))

                    @if($bat->level_value == 'l23' )

                      {{$bat->usd_value * 23}}

                    @elseif( $bat->level_value == 'l29' )
                      
                      {{$bat->usd_value * 29}}


                    @endif

                  @elseif( !isset( $bat->radio_value ))

                    {{ count($checkboxvalue) * $bat->usd_value }}
                  
                  @endif

                @endforeach


                </td>
                <td></td>
                <td>{{ $bat->created_at}}</td>

              </tr>
              @php }else{

              @endphp


              @foreach ($data as $bat)

                @for( $i = 0; $i < count($bat); $i++)
            
                  <tr>
              
                    <td>{{ $bat[$i]->d2_value }}</td>
              
                    <td>{{ $bat[$i]->usd_value }}</td>
              
                    <td>{{ $bat[$i]->khr_value }}</td>

                    <td>@if(isset( $bat[$i]->checkbox_value ))

                      {{ $bat[$i]->checkbox_value }}

                      <?php $checkboxval = count($checkboxvalue);?>

                      @elseif(isset( $bat[$i]->level_value ))

                      {{ $bat[$i]->level_value }}

                      <?php 

                      if($bat[$i]->level_value == 'l23'){

                        $checkboxval = 23;
                        
                      }elseif($bat[$i]->level_value == 'l29'){

                        $checkboxval = 29;

                      };?>

                      @endif

                    </td>

              
                <td>{{ $bat[$i]->created_at}}</td>
              
                  </tr>
                  @endfor
              @endforeach

              <tr>
                
                <td>Total</td>
               
                <td>

                  <?php $countcheckboxval = 0; $batval = 0;?>
                  
                @foreach ($data as $bat)

                @for( $i = 0; $i < count($bat); $i++)
                  
                  @if(isset( $bat[$i]->radio_value ))

                    @if( $bat[$i]->radio_value == '5OD' || $bat[$i]->radio_value == '5S' )  

                      @if(isset( $bat[$i]->checkbox_value )) 

                       <?php  $countcheckboxval = count($checkboxvalue);?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value  * $countcheckboxval );?>
                      
                      @elseif(isset( $bat[$i]->level_value ))
                        
                        @if($bat[$i]->level_value == 'l23' )

                        <?php $batval = $batval + ( $bat[$i]->usd_value * 23 ) ;?>

                      @elseif( $bat[$i]->level_value == 'l29' )
                      
                        <?php $batval = $batval + ( $bat[$i]->usd_value * 29 ) ;?>

                      @endif
                    @endif

                    @elseif( $bat[$i]->radio_value == '10S' )

                      @if(isset( $bat[$i]->checkbox_value )) 

                    <?php  $countcheckboxval = count($checkboxvalue);?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value  * $countcheckboxval );?>

                  @elseif(isset( $bat[$i]->level_value ))

                    @if($bat[$i]->level_value == 'l23' )

                      <?php $batval = $batval + ( $bat[$i]->usd_value * 23 ) ;?>

                    @elseif( $bat[$i]->level_value == 'l29' )
                      
                      <?php $batval = $batval + ( $bat[$i]->usd_value * 29 ) ;?>

                    @endif  


                  @elseif( !isset( $bat[$i]->radio_value ))

                    <?php $batval = count($checkboxvalue) * $bat->usd_value;?>
                                      
                  @endif
                  @endif
                  @endif

                @endfor
                @endforeach
                <?php echo $batval;?>
                @php } @endphp 
                </td>
                <td></td>
               

              </tr>
              
                </tbody>
              
              </table>
              
            @endif


            @if(isset($successmsg))

              <div class="alert alert-success"> {{ $successmsg }}</div>

            @endif
            
            @if( Session::has( 'errormessage' ))

              <div class="alert alert-success"> {{ Session::get( 'errormessage' ) }}</div>

            @endif

            <button type="submit" class="btn btn-primary" id="add">+ Add More Fields</button>

            <form action="<?php echo url('/');?>/dashboard/2d-betform" method="POST">
              
              @csrf

              <input type="hidden" id="lastlevel" value="1" />

              <div class="first-line">

                <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div>

                <div class="form-group">
                
                  <label for="2d">2D:</label>
                
                  <input type="text" id="2d1" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed">
                
                </div>

                 <div class="form-group">
                
                  <label for="usd">USD:</label>
                
                  <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) ">
                
                </div>

                <div class="form-group">
                
                  <label for="khr">KHR:</label>
                
                  <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )">
                
                </div>

              </div>

              <div class="radio">

                <label class="radio-inline"><input type="radio" name="optradio" value="5OD">5 OD</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="5S">5 S</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="10S">10 S</label>

              </div>

              <div class="checkbox">
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="A" name="checkbox[]">A</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="B" name="checkbox[]">B</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="C" name="checkbox[]">C</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="D" name="checkbox[]">D</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="H" name="checkbox[]">H</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="I" name="checkbox[]">I</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="N" name="checkbox[]">N</label>

              </div>

               <input type="hidden" value="" id="checkbox-val">

              <div class="checkbox">
                
                <label class="checkbox-inline"><input type="checkbox" id="l23" value="l23" class="checkLevel" name="level_checkbox[]">L 23</label>
                
                <label class="checkbox-inline"><input type="checkbox" id="l29" value="l29" class="checkLevel" name="level_checkbox[]">L 29</label>
                
              </div>

              <button type="submit" class="btn btn-default">Submit</button>
            
            </form>            

            <br/>

@endsection



@section('footer')

<script type="text/javascript" src="<?php echo url('/');?>/js/script.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>

<script src="<?php echo url('/');?>/js/tableHTMLExport.js"></script>

<script>
  
  $(document).on('click', '#pdf' ,function(){
    $("#example").tableHTMLExport({type:'pdf',filename:'report.pdf'});
  });

</script>

<script type="text/javascript">
  
  $(document).ready(function(){

    $('#add').click(function(event){

      var level = $('#lastlevel').val();

      console.log("level is " + level);

      var txt2d = $('#2d'+level).val();

      var usd = $('#usd'+level).val();

      var khr = $('#khr'+level).val();

      console.log("2d value is " + txt2d);

      if( txt2d != '' && txt2d.length == 2 &&(usd != '' || khr != '')){

        var radioValue = $("input[name='optradio']:checked").val();
        
        if(radioValue){
        
          console.log("Your are a - " + radioValue);
          
          txt2d = parseInt(txt2d);

          if(radioValue == '5OD'){

            if(level > '4'){

               swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 2;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>');

            }

          }else if(radioValue == '5S'){

            if(level > '4'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 1;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

          }else if(radioValue == '10S'){

             if(level == 10){

            console.log('matched');

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{
              console.log('not matched');

              txt2d = txt2d + 1;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 
    
            }

          }else{
            // console.log('nothing matched');
            swal("Oops!", "Please handle checkbox validation error!", "warning");
            // nothing goes here all checkbox conditions have been checked above
          }

          }else{

            swal("Oops!", "Please select any of the radiobutton!", "warning");

          }  

        }else{

          swal("Oops!", "Please input all fields before adding extra fields!", "warning");
       
        }

    });

  });

  $(document).on('click', '.radio-inline', function(){

     var d2val = $('#2d1').val();

      var usdval = $('#usd1').val();

      var khrval = $('#khr1').val();

      // console.log(d3val);

      // console.log(usdval);

      // console.log(khrval);

      $('#lastlevel').val('1');

      $('.first-line').html(' <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d1" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+d2val+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usdval+'"> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khrval+'"> </div>');

    });


  $(document).on('keypress', '.2d', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

       if (event.which > 47 &&  event.which < 58  && targetValue.length < 2) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if (result < 0 || result > 99) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }
       
       else {
       
           event.preventDefault();
       
       }


    });

  $(document).on('keypress', '.usd', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        console.log(targetValue);

        console.log(event.keyCode);

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

        // if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
          
        //   event.preventDefault();
        
        // }else{
        
        if (event.which > 47 &&  event.which < 58  && targetValue.length < 6) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if (result < 0 || result > 99) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }

       
       else {
       
           event.preventDefault();
       
       }

    });

  $(document).on('click', '.checkLevel', function(){

 var checked = $(this).prop('checked');

    if(checked){

      var checkboxValue = $(this).val();

      $('#checkbox-val').val('upper');

      console.log(checkboxValue);

      if(checkboxValue == 'l23'){

        $('#l29').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }else if(checkboxValue == 'l29'){

        $('#l23').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }

    }else{

      console.log('checkbox unclicked');

      $('#checkbox-val').val('lower');

    }

  });


  $(document).on('click', '.singleCheckbox', function(){

     var checked = $(this).prop('checked');

    if(checked){

        $('#checkbox-val').val('upper');
        
        $('#l23').prop('checked', false);

        $('#l29').prop('checked', false);

    }else{

        console.log('checkbox unclicked');

        $('#checkbox-val').val('lower');

        console.log($('#checkbox-val').val());

    }

  });

  $(document).on('click', '.btn-default', function(event){

    // alert('asasas');

    var txt2d = $('#2d1').val();

    var usd = $('#usd1').val();

    var khr = $('#khr1').val();

    console.log(txt2d);

    console.log(usd);

    console.log(khr);

 if(txt2d != "" && txt2d.length == 2){

      if((usd != "") || (khr != "" && khr.length == 2)){

        var status = $('#checkbox-val').val();

          if(status == 'upper'){

          // event.preventDefault();
          
          // swal("Oops!", "Checkbox checked!", "warning");

        }else if(status == 'lower'){

          event.preventDefault();

          console.log('status is false but still it is showing this message');
          
          swal("Oops!", "None of the checkbox is checked!", "warning");

        }else{

          event.preventDefault();

          swal("Oops!", "Please check any of the checkboxes before moving further.", "warning");          

        }

        // $('#3dform').submit();

          // event.preventDefault();
          
          // swal("Oops!", "Condition satisfied!", "warning"); 

      }else{

        event.preventDefault();

        swal("Oops!", "Please input either USD or KHR in valid format!", "warning");
      }

    }else{

      event.preventDefault();
           
      swal("Oops!", "Please input 3D field with minimum 3 digits between 101-999 before moving forward!", "warning");

    }

  });

</script>

@endsection