@extends('layouts.website')


@section('title')

Lottery | Dashboard

@endsection

@section('content')

            <div class="card-header"><h2>Add User</h2></div>

            <p>Add users with different parameters to allow them to trade.</p>

            @if( Session::has( 'errormsg' ))

              <div class="alert alert-success"> {{ Session::get( 'successmsg' ) }}</div>

            @endif
            
            @if( Session::has( 'errormsg' ))

              <div class="alert alert-success"> {{ Session::get( 'errormsg' ) }}</div>

            @endif

            <form action="<?php echo url('/');?>/dashboard/add-users" method="POST">
              
              @csrf

              <div class="form-group">
              
                <label for="username">Username:</label>
              
                <input type="text" class="form-control" id="username" name="name">
              
              </div>

              <div class="form-group">
              
                <label for="fullname">Full Name:</label>
              
                <input type="text" class="form-control" id="fullname" name="fullname">
              
              </div>

              <div class="form-group">
              
                <label for="email">Email address:</label>
              
                <input type="email" class="form-control" id="email" name="email">
              
              </div>
              
              <div class="form-group">
              
                <label for="pwd">Password:</label>
              
                <input type="password" class="form-control" id="pwd" name="password">
              
              </div>

              <div class="form-group">
    
                <label for="userlevel">Select User Level:</label>
                    
                    <select class="form-control" id="userlevel" name="userlevel">
    
                        <option value="1">Level A</option>
    
                    </select>
               
               </div>

               <div class="form-group">
              
                <label for="balanceusd">Balance USD:</label>
              
                <input type="text" class="form-control" id="balanceusd" name="balanceUSD">
              
              </div>

              <div class="form-group">
              
                <label for="balancekhr">Balanace KHR:</label>
              
                <input type="text" class="form-control" id="balancekhr" name="balanceKHR">
              
              </div>

              <div class="form-group">
              
                <label for="userpercent">User Percent:</label>
              
                <input type="text" class="form-control" id="userpercent" name="userpercent">
              
              </div>

              <div class="form-group">
              
                <label for="phone">Phone:</label>
              
                <input type="text" class="form-control" id="phone" name="phone">
              
              </div>

              <div class="form-group">
              
                <label for="address">Address:</label>
              
                <input type="text" class="form-control" id="address" name="address">
              
              </div>
              
              <button type="submit" class="btn btn-default">Submit</button>
            
            </form>            

            <br/>

@endsection



@section('footer')

<script type="text/javascript" src="js/script.js"></script>
@endsection