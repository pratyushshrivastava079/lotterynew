<?php $__env->startSection('title'); ?>

Lottery | Dashboard

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <div class="card-header"><strong><h2>Control CheckBox Visibility</h2></strong></div>
              <p>The list consists of all the users on the website.</p>   

               <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Checkbox Name</th>
                    <th>Status</th>
                    <th>Toggle</th>
                    <th>Updated At</th>
                  </tr>

                </thead>
                <tbody>

                </tbody>

                <tr>
                  <td>1.</td>
                   <td>A Field</td>
                   <td>Shown</td>
 <td>    

                    <label class="switch" id="switch">
                    
                    <?php if($data[0]->A_status == 1){?>
        
                    <button id="checkboxs" class="btn btn-danger" data-val="A">Hidden</button>
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="A">Hide Me</button>
                <?php }?>
                  </label></td>
                   <td><?php echo $data[0]->updated_at;?></td>

                 </tr>

                 <tr>
                  <td>2.</td>
                   <td>B Field</td>
                   <td>Shown</td>
                   <td>    

                    <label class="switch" id="switch">

                    <?php if($data[0]->B_status == 1){?>
                    <button id="checkboxs" class="btn btn-danger" data-val="B">Hidden</button>
        
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="B">Hide Me</button>
                    <?php }?>
                  </label></td>

                   <td><?php echo $data[0]->updated_at;?></td>
                 </tr>

                 <tr>
                  <td>3.</td>
                   <td>C Field</td>
                   <td>Shown</td>
                   <td>    

                    <label class="switch" id="switch">

                    <?php if($data[0]->C_status == 1){?>
                    
                    <button id="checkboxs" class="btn btn-danger" data-val="C">Hidden</button>

                    <?php }else{?>

                    <button id="checkbox" class="btn btn-primary" data-val="C">Hide Me</button>
                    <?php }?>
                  </label></td> 
                   <td><?php echo $data[0]->updated_at;?></td>

                 </tr>

                 <tr>
                  <td>4.</td>
                   <td>D Field</td>
                   <td>Shown</td>
                     <td>    

                    <label class="switch" id="switch">

                    <?php if($data[0]->D_status == 1){?>

                    <button id="checkboxs" class="btn btn-danger" data-val="D" >Hidden</button>
        
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="D">Hide Me</button>
                    <?php }?>
                  </label></td>
                   <td><?php echo $data[0]->updated_at;?></td>

                 </tr>

                 <tr>
                  <td>5.</td>
                   <td>H Field</td>
                   <td>Shown</td>
                    <td>    

                    <label class="switch" id="switch">
                    
                    <?php if($data[0]->H_status == 1){?>
                      

                    <button id="checkboxs" class="btn btn-danger" data-val="H" >Hidden</button>
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="H">Hide Me</button>
                      <?php }?>
                  </label></td>
                   <td><?php echo $data[0]->updated_at;?></td>

                 </tr>

                 <tr>
                  <td>6.</td>
                     <td>I Field</td>
                   <td>Shown</td>
                    <td>    

                    <label class="switch" id="switch">
                    
                    <?php if($data[0]->I_status == 1){?>

                    <button id="checkboxs" class="btn btn-danger" data-val="I" >Hidden</button>
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="I">Hide Me</button>
                    <?php }?>
                  </label></td>
                   <td><?php echo $data[0]->updated_at;?></td>

                   </tr>

                   <tr>
                  <td>7.</td>
                   <td>N Field</td>
                   <td>Shown</td>
                    <td>    

                    <label class="switch" id="switch">
                      
                                        <?php if($data[0]->N_status == 1){?>
                    <button id="checkboxs" class="btn btn-danger" data-val="N" >Hidden</button>
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="N">Hide Me</button>
                    <?php }?>
                  </label></td>
        
                   <td><?php echo $data[0]->updated_at;?></td>

                 </tr>
                   <tr>
                  <td>8.</td>
                   <td>l19 Field</td>
                   <td>Shown</td>
                    <td>    

                    <label class="switch" id="switch">
                    
                                        <?php if($data[0]->l19_status == 1){?>
                    <button id="checkboxs" class="btn btn-danger" data-val="l19" >Hidden</button>
                    <?php }else{?>
                    <button id="checkbox" class="btn btn-primary" data-val="l19">Hide Me</button>
                  <?php }?>
                  </label></td>
                   <td><?php echo $data[0]->updated_at;?></td>

                 </tr>
                   <tr>
                  <td>9.</td>
                   <td>l22 Field</td>
                   <td>Shown</td>
                      <td>    

                    <label class="switch" id="switch">

                    <?php if($data[0]->l22_status == 1){?>
        
                    <button id="checkboxs" class="btn btn-danger" data-val="l22" >Hidden</button>

                    <?php }else{?>

                    <button id="checkbox" class="btn btn-primary" data-val="l22">Hide Me</button>
                    
                    <?php }?>

                  </label></td>

                   <td><?php echo $data[0]->updated_at;?></td>
                 </tr>

              </table>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="<?php echo url('/');?>js/script.js"></script>

<script type="text/javascript">

  $(document).on('click', '#checkbox', function(){

    var data = $(this).data('val');
    
 $.ajax({

        url: "<?php echo URL::to('/');?>/dashboard/checkbox-status",

        headers: {
                    
          'X-CSRF-TOKEN':'<?php echo csrf_token() ?>',
                
        },

        type: 'POST',

        data: { 'status' : 1, 'data': data },

        success:function(response){

          var result = JSON.parse(response);

          // $('#addparentUsername').val(result.username);

          if(result.status == 1){

            swal({
  title: "Success",
  text: "The field has been hidden from form.",
  icon: "success",
  buttons: true,

})
.then((willDelete) => {
window.location.reload();
});

          }else if(result.status == 0){

            swal({
  title: "Success",
  text: "The field has been shown in the form",
  icon: "success",
  buttons: true,
})
.then((willDelete) => {
window.location.reload();

});
        
        }

      }

      });


  });


   $(document).on('click', '#checkboxs', function(){

    var data = $(this).data('val');
    
 $.ajax({

        url: "<?php echo URL::to('/');?>/dashboard/checkboxs-status",

        headers: {
                    
          'X-CSRF-TOKEN':'<?php echo csrf_token() ?>',
                
        },

        type: 'POST',

        data: { 'status' : 1, 'data': data },

        success:function(response){

          var result = JSON.parse(response);

          // $('#addparentUsername').val(result.username);

          console.log(result);

          if(result.status == 1){

            swal({
  title: "Success",
  text: "The field has been hidden from form.",
  icon: "success",
  buttons: true,

})
.then((willDelete) => {
window.location.reload();
});

          }else if(result.status == 0){

            swal({
  title: "Success",
  text: "The field has been shown in the form",
  icon: "success",
  buttons: true,
})
.then((willDelete) => {
window.location.reload();

});



}        }

      });


  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/checkbox-status.blade.php */ ?>