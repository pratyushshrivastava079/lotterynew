<?php $__env->startSection('title'); ?>

Lottery | Dashboard

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- Bootstrap Modal to edit user details -->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title text-center">Add User</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
         <form id="addsubuser" method="POST">
              
              <?php echo csrf_field(); ?>

              <div class="form-group">
              
                <label for="username">Username:</label>
              
                <input type="text" class="form-control" id="addusername" name="name">
              
              </div>

              <div class="form-group">
              
                <label for="fullname">Full Name:</label>
              
                <input type="text" class="form-control" id="addfullname" name="fullname">
              
              </div>

              <div class="form-group">
              
                <label for="email">Parent Username:</label>
              
                <input type="text" class="form-control" id="addparentUsername" name="parentUsername">
              
              </div>
              
              <div class="form-group">
              
                <label for="pwd">Password:</label>
              
                <input type="password" class="form-control" id="addpassword" name="password">
              
              </div>

              <div class="form-group">
    
                <label for="userlevel">Select User Level:</label>
                    
                    <select class="form-control" id="adduserlevel" name="userlevel">
    
                        <option value="2">Level B</option>
    
                        <option value="3">Level C</option>
    
                        <option value="4">Level D</option>
    
                    </select>
               
               </div>

              <div class="form-group">
              
                <label for="phone">Phone:</label>
              
                <input type="text" class="form-control" id="addphone" name="phone">
              
              </div>

              <div class="form-group">
              
                <label for="address">Address:</label>
              
                <input type="text" class="form-control" id="addaddress" name="address">
              
              </div>
              
              <button type="submit" class="btn btn-primary" id="subuser">Submit</button>
            
            </form>
      </div>
     <!--  <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div> -->
    </div>

  </div>
</div>

            <div class="card-header"><strong><h2>User List</h2></strong></div>
              <p>The list consists of all the users on the website.</p>   
                <?php if(empty($error)): ?>

              <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Add Users</th>
                    <th>Username</th>
                    <th>Added By</th>
                    <th>Level of User</th>
                    <th>Created At</th>
                    <th>Action</th>
                  </tr>

                </thead>
                <tbody>
                  <?php  

                   if(isset($_GET['page'])){

                    if(is_numeric($_GET['page'])){

                        $page = $_GET['page'];

                        if($page != 1){

                            $page = $page * 10;

                            $page = $page - 9;
                        
                        }

                        }else{

                            $page = 1;
                        }

                    }else{

                        $page = 1;
                    }

                        ?>
        
                  <?php   foreach ($users as $user) {          
              
if($user->accountType == 1){

                            $accountType = "Level A";

                        }elseif($user->accountType == 2){

                            $accountType = "Level B";

                        }elseif($user->accountType == 3){

                            $accountType = "Level C";                            

                        }?>

                     <tr>
                    <td><a href="<?php echo url('/');?>/dashboard/adduserlevel/<?php echo e($user->id); ?>"><button class="btn btn-primary add-users" data-id="<?php echo e($user->id); ?>" data-username="<?php echo e($user->name); ?>" data-level="<?php echo $user->accountType;?>">+</button></a></td>

                    <td><?php echo e($user->name); ?></td>

                    <td>None</td>

                    <td><?php echo e($user->accountType); ?></td>
                
                    <td><?php echo e($user->created_at); ?></td>
                
                    <td><span data-toggle="modal" data-target="#myModal"><i class="fa fa-pencil"></i></span>&nbsp&nbsp<span><i class="fa fa-trash" data-id="<?php echo e($user->id); ?>"></i></span></td>
                
                  </tr>
                
                  <?php $page++;  }?>

               <?php else: ?>
                  <div class="alert alert-danger"><?php echo e($error); ?></div>
               <?php endif; ?> 

                </tbody>

              </table>


                                      


<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="<?php echo url('/');?>js/script.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/level.blade.php */ ?>