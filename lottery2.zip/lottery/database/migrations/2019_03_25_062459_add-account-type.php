<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddAccountType extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // adding account type for users while registering

        Schema::table('users', function (Blueprint $table) {
            
            $table->char('accountType', 255)->default('1');  
        
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //dropping account type for users while deleting terms from database
     
        Schema::table('users', function (Blueprint $table) {
            
            $table->dropColumn('accountType');
        
        });
    }
}
