<?php $__env->startSection('title'); ?>

Lottery | Dashboard | 3d Betform

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="card-header"><h2>Form</h2></div>

            <p>3D bet form for different level users.</p>

           <?php if(!isset($errors)): ?> 
                <?php echo e($errors); ?>


            <?php endif; ?>

            <?php if($errors->any()): ?>
              
              <div class="alert alert-danger">
                
                <ul>
              
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <li><?php echo e($error); ?></li>
                
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </ul>
              
              </div>
          
            <?php endif; ?>

            <?php if(isset( $data )): ?>

            <button class="btn btn-primary" id="pdf">Print</button>

              <table class="table table-hover table-respponsive" id="example">
              
                <thead>
              
                  <tr>
              
                    <th>3D</th>
              
                    <th>USD</th>
              
                    <th>KHR</th>
              
                    <th>PO</th>
                    
                    <th>PUSD</th>
                    
                    <th>PKHR</th>
                    
                    <th>DATETIME</th>
              
                  </tr>
              
                </thead>
              
              <tbody> 
              <?php
                
                $datacount = count($data);


                if($datacount == 1){
              
              ?>

               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
              
                    <td><?php echo e($bat->d3_value); ?></td>
              
                    <td><?php echo e($bat->usd_value); ?></td>
              
                    <td><?php echo e($bat->khr_value); ?></td>

                    <td><?php if(isset( $bat->checkbox_value )): ?>

                      <?php echo e($bat->checkbox_value); ?>


                      <?php elseif(isset( $bat->level_value )): ?>

                      <?php echo e($bat->level_value); ?>


                      <?php endif; ?>

                    </td>

                <td> <?php echo e($bat->usd_value); ?></td>
                <td><?php echo e($bat->khr_value); ?></td>
                <td><?php echo e($bat->created_at); ?></td>
              
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                
                <td>Total</td>
                <td></td>
                <td></td>
                <td></td>

                <td>

                  <?php $countcheckboxval = 0; $batval = 0;?>
                
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if(isset( $bat->radio_value )): ?>

                    <?php if( $bat->radio_value == '5OD' || $bat->radio_value == '5L' || $bat->radio_value == '5C' || $bat->radio_value == '5R' ): ?>  
                     
                      <?php if(isset( $bat->checkbox_value )): ?> 

                        $countcheckboxval = count($checkboxval);

                        $batval = $batval + $bat->usd_value;
                      
                        <?php echo e($countcheckboxval * $batval * 5); ?>

                    
                      <?php if($bat->level_value == 'l22' ): ?>

                        <?php echo e($bat->usd_value * 5 * 22); ?>


                      <?php elseif( $bat->level_value == 'l19' ): ?>
                      
                        <?php echo e($bat->usd_value * 5 * 19); ?>


                      <?php endif; ?>

                    <?php endif; ?>

                    <?php elseif( $bat->radio_value == '10L' || $bat->radio_value == '10C' || $bat->radio_value == '10R' ): ?>

                      <?php if(isset( $bat->checkbox_value )): ?> 

                        <?php echo e(count($checkboxvalue) * $bat->usd_value * 10); ?>


                    <?php endif; ?>

                  <?php endif; ?>

                  <?php elseif(isset( $bat->level_value )): ?>

                    <?php if($bat->level_value == 'l22' ): ?>

                      <?php echo e($bat->usd_value * 22); ?>


                    <?php elseif( $bat->level_value == 'l19' ): ?>
                      
                      <?php echo e($bat->usd_value * 19); ?>



                    <?php endif; ?>

                  <?php elseif( !isset( $bat->radio_value )): ?>

                    <?php echo e(count($checkboxvalue) * $bat->usd_value); ?>

                  
                  <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </td>
                <td></td>
                <td><?php echo e($bat->created_at); ?></td>

              </tr>
              <?php }else{

              ?>


              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php for( $i = 0; $i < count($bat); $i++): ?>
            
                  <tr>
              
                    <td><?php echo e($bat[$i]->d3_value); ?></td>
              
                    <td><?php echo e($bat[$i]->usd_value); ?></td>
              
                    <td><?php echo e($bat[$i]->khr_value); ?></td>

                    <td><?php if(isset( $bat[$i]->checkbox_value )): ?>

                      <?php echo e($bat[$i]->checkbox_value); ?>


                      <?php $checkboxval = count($checkboxvalue);?>

                      <?php elseif(isset( $bat[$i]->level_value )): ?>

                      <?php echo e($bat[$i]->level_value); ?>


                      <?php 

                      if($bat[$i]->level_value == 'l19'){

                        $checkboxval = 19;
                        
                      }elseif($bat[$i]->level_value == 'l22'){

                        $checkboxval = 22;

                      };?>

                      <?php endif; ?>

                    </td>

                <td><?php echo e($checkboxval * $bat[$i]->usd_value); ?></td>
                <td><?php echo e($checkboxval * $bat[$i]->khr_value); ?></td>
                <td><?php echo e($bat[$i]->created_at); ?></td>
              
                  </tr>
                  <?php endfor; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                
                <td>Total</td>
                <td></td>
                <td></td>
                <td></td>

                <td>

                  <?php $countcheckboxval = 0; $batval = 0;?>
                  
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php for( $i = 0; $i < count($bat); $i++): ?>
                  
                  <?php if(isset( $bat[$i]->radio_value )): ?>

                    <?php if( $bat[$i]->radio_value == '5OD' || $bat[$i]->radio_value == '5L' || $bat[$i]->radio_value == '5C' || $bat[$i]->radio_value == '5R' ): ?>  

                      <?php if(isset( $bat[$i]->checkbox_value )): ?> 

                       <?php  $countcheckboxval = count($checkboxvalue);?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value  * $countcheckboxval );?>
                      
                      <?php elseif(isset( $bat[$i]->level_value )): ?>
                        
                        <?php if($bat[$i]->level_value == 'l22' ): ?>

                        <?php $batval = $batval + ( $bat[$i]->usd_value * 22 ) ;?>

                      <?php elseif( $bat[$i]->level_value == 'l19' ): ?>
                      
                        <?php $batval = $batval + ( $bat[$i]->usd_value * 19 ) ;?>

                      <?php endif; ?>
                    <?php endif; ?>

                    <?php elseif( $bat[$i]->radio_value == '10L' || $bat[$i]->radio_value == '10C' || $bat[$i]->radio_value == '10R' ): ?>

                      <?php if(isset( $bat[$i]->checkbox_value )): ?> 

                    <?php  $countcheckboxval = count($checkboxvalue);?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value  * $countcheckboxval );?>

                  <?php elseif(isset( $bat[$i]->level_value )): ?>

                    <?php if($bat[$i]->level_value == 'l22' ): ?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value * 22 ) ;?>

                    <?php elseif( $bat[$i]->level_value == 'l19' ): ?>
                      
                      <?php $batval = $batval + ( $bat[$i]->usd_value * 19 ) ;?>

                    <?php endif; ?>


                  <?php elseif( !isset( $bat[$i]->radio_value )): ?>

                    <?php $batval = count($checkboxvalue) * $bat->usd_value;?>
                                      
                  <?php endif; ?>
                  <?php endif; ?>
                  <?php endif; ?>

                <?php endfor; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $batval;?>
                <?php } ?> 
                </td>
                <td></td>
                <td><?php echo e($data[0][0]->created_at); ?></td>

              </tr>
              
                </tbody>
              
              </table>
              
            <?php endif; ?>


            <?php if(isset($successmsg)): ?>

              <div class="alert alert-success"> <?php echo e($successmsg); ?></div>

            <?php endif; ?>
            
            <?php if( Session::has( 'errormessage' )): ?>

              <div class="alert alert-success"> <?php echo e(Session::get( 'errormessage' )); ?></div>

            <?php endif; ?>

            <button type="submit" class="btn btn-primary" id="add">+ Add More Fields</button>

            <form action="<?php echo url('/');?>/dashboard/3d-betform" method="POST" id="3dform">
              
              <?php echo csrf_field(); ?>

              <input type="hidden" id="lastlevel" value="1" />

              <div class="first-line">

                <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div>

                <div class="form-group">
                
                  <label for="3d">3D:</label>
                
                  <input type="text" id="3d1" class="form-control 3d" name="txt3d[]" placeholder="Only 3 digit number between 101-999 allowed">
                
                </div>

                 <div class="form-group">
                
                  <label for="usd">USD:</label>
                
                  <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) ">
                
                </div>

                <div class="form-group">
                
                  <label for="khr">KHR:</label>
                
                  <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )">
                
                </div>

              </div>

              <div class="radio">

                <label class="radio-inline"><input type="radio" name="optradio" value="5OD">5 X</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="5L">5 L</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="5C">5 C</label>

                <label class="radio-inline"><input type="radio" name="optradio" value="5R">5 R</label>

                <label class="radio-inline"><input type="radio" name="optradio" value="10L">10 L</label>

                <label class="radio-inline"><input type="radio" name="optradio" value="10C">10 C</label>

                <label class="radio-inline"><input type="radio" name="optradio" value="10R">10 R</label>

              </div>

              <div class="checkbox upper">
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="A" name="checkbox[]">A</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="B" name="checkbox[]">B</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="C" name="checkbox[]">C</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="D" name="checkbox[]">D</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="H" name="checkbox[]">H</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="I" name="checkbox[]">I</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="N" name="checkbox[]">N</label>

              </div>

              <input type="hidden" value="" id="checkbox-val">

              <div class="checkbox lower">
                
                <label class="checkbox-inline"><input type="checkbox" id="l19" value="l19" class="checkLevel" name="level_checkbox[]">L 19</label>
                
                <label class="checkbox-inline"><input type="checkbox" id="l22" value="l22" class="checkLevel" name="level_checkbox[]">L 22</label>
                
              </div>

              <button type="submit" class="btn btn-default">Submit</button>
            
            </form>            

            <br/>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="<?php echo url('/');?>/js/script.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>

<script src="<?php echo url('/');?>/js/tableHTMLExport.js"></script>

<script>
  
  $(document).on('click', '#pdf' ,function(){
  
    $("#example").tableHTMLExport({type:'pdf',filename:'report.pdf'});
  
  });

</script>

<script type="text/javascript">

  var permArr = [];

  var usedChars = [];

  function permute(input) {
    
    var i, ch;
    
    for (i = 0; i < input.length; i++) {
      
      ch = input.splice(i, 1)[0];
      
      usedChars.push(ch);
    
    if (input.length == 0) {
    
      permArr.push(usedChars.slice());
    
    }
    
    permute(input);
    
    input.splice(i, 0, ch);
    
    usedChars.pop();
  
  }
  
    return permArr

  };
  
  $(document).ready(function(){

    $('#add').click(function(event){

      var level = $('#lastlevel').val();

      console.log("level is " + level);

      var txt3d = $('#3d'+level).val();

      var usd = $('#usd'+level).val();

      var khr = $('#khr'+level).val();

      console.log("3d value is " + txt3d);

      if( txt3d != '' && txt3d.length == 3 &&(usd != '' || khr != '')){

        var radioValue = $("input[name='optradio']:checked").val();

        console.log(radioValue);
        
        if(radioValue){
        
          console.log("Your are a - " + radioValue);
          
          txt3d = parseInt(txt3d);

          if(radioValue == '5OD'){

            if(level > '4'){

               swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              console.log(ab.length);

              // var val = parseInt(ab[1]);
          
              // var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              // var result = textVal + 1;

              // txt3d = txt3d + 2;
              // console.log("after abplus " + result );

              // result = result.toString();

              // ab = ab[0]+result+ab[2];

              // ab = ab.split("");
              var result = JSON.stringify(permute(ab))

              console.log("result is " + result[0]);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt3d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>');

            }

          }else if(radioValue == '5L'){

            if(level > '4'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              var val = parseInt(ab[0]);
          
              var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              var result = textVal + 1;

              // txt3d = txt3d + 2;
              console.log("after abplus " + result );

              result = result.toString();

              ab = result+ab[1]+ab[2];

              console.log("ab result is " + ab);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+ab+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

          }else if(radioValue == '5C'){

             if(level > '4'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              var val = parseInt(ab[1]);
          
              var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              var result = textVal + 1;

              // txt3d = txt3d + 2;
              console.log("after abplus " + result );

              result = result.toString();

              ab = ab[0]+result+ab[2];

              console.log("ab result is " + ab);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+ab+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

           }else if(radioValue == '5R'){

             if(level > '4'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              var val = parseInt(ab[2]);
          
              var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              var result = textVal + 1;

              // txt3d = txt3d + 2;
              console.log("after abplus " + result );

              result = result.toString();

              ab = ab[0]+ab[1]+result;

              console.log("ab result is " + ab);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+ab+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }
            
          }else if(radioValue == '10L'){

             if(level > '9'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              var val = parseInt(ab[0]);
          
              var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              var result = textVal + 1;

              // txt3d = txt3d + 2;
              console.log("after abplus " + result );

              result = result.toString();

              ab = result+ab[1]+ab[2];

              console.log("ab result is " + ab);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+ab+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }    

          }else if(radioValue == '10C'){

             if(level > '9'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              var val = parseInt(ab[1]);
          
              var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              var result = textVal + 1;

              // txt3d = txt3d + 2;
              console.log("after abplus " + result );

              result = result.toString();

              ab = ab[0]+result+ab[2];

              console.log("ab result is " + ab);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+ab+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

          }else if(radioValue == '10R'){

             if(level > '9'){

             swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              var ab = txt3d.toString();
              
              ab = ab.split("");

              var val = parseInt(ab[2]);
          
              var textVal = parseInt(val || "0");
          
              // ab[0] = ab[0]+1;
              var result = textVal + 1;

              // txt3d = txt3d + 2;
              console.log("after abplus " + result );

              result = result.toString();

              ab = ab[0]+ab[1]+result;

              console.log("ab result is " + ab);

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d'+level+'" class="form-control 3d" name="txt3d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+ab+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

          }else{

            swal("Oops!", "Please handle checkbox validation error!", "warning");

            // nothing goes here all checkbox conditions have been checked above

          }

          }else{

            swal("Oops!", "Please select any of the radiobutton!", "warning");

          }  

        }else{

          swal("Oops!", "Please input aal fields before adding extra fields!", "warning");
       
        }

    });

  });

  $(document).on('click', '.radio-inline', function(){


      var d3val = $('#3d1').val();

      var usdval = $('#usd1').val();

      var khrval = $('#khr1').val();

      // console.log(d3val);

      // console.log(usdval);

      // console.log(khrval);

      $('#lastlevel').val('1');

      $('.first-line').html(' <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div><div class="form-group"> <label for="3d">3d:</label> <input type="text" id="3d1" class="form-control 3d" name="txt3d[]" placeholder="Only 3 digit number between 101-999 allowed" value="'+d3val+'"> </div><div class="form-group"><label for="usd">USD:</label><input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 )" value="'+usdval+'"> </div><div class="form-group"><label for="khr">KHR:</label><input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khrval+'"></div>');

    });


  $(document).on('keypress', '.3d', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        console.log("target value is " + targetValue);

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

       if (event.which > 47 &&  event.which < 58  && targetValue.length < 3) {

          // if( targetValue > 101 && targetValue < 999 ){
        
            var c = String.fromCharCode(event.which);

            var val = parseInt(c);
          
            var textVal = parseInt(targetValue || "0");
          
            var result = textVal + val;

            if (result < 0 || result > 99) {
          
               event.preventDefault();
          
            }
       
       }
       
       else {
       
           event.preventDefault();
       
       }


    });

  $(document).on('keypress', '.usd', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        console.log(targetValue);

        console.log(event.keyCode);

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

        // if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
          
        //   event.preventDefault();
        
        // }else{
        
        if (event.which > 47 &&  event.which < 58  && targetValue.length < 6) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if ( result < 0 ) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }

       
       else {
       
           event.preventDefault();
       
       }

    });

  $(document).on('click', '.checkLevel', function(){

    var checked = $(this).prop('checked');

    if(checked){

      var checkboxValue = $(this).val();

      $('#checkbox-val').val('upper');

      console.log(checkboxValue);

      if(checkboxValue == 'l19'){

        $('#l22').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }else if(checkboxValue == 'l22'){

        $('#l19').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }

    }else{

      console.log('checkbox unclicked');

      $('#checkbox-val').val('lower');

    }

  });


  $(document).on('click', '.singleCheckbox', function(){

    var checked = $(this).prop('checked');

    if(checked){

        $('#checkbox-val').val('upper');
        
        $('#l19').prop('checked', false);

        $('#l22').prop('checked', false);

    }else{

        console.log('checkbox unclicked');

        $('#checkbox-val').val('lower');

        console.log($('#checkbox-val').val());

    }

  });

  $(document).on('click', '.btn-default', function(event){

    var txt3d = $('#3d1').val();

    var usd = $('#usd1').val();

    var khr = $('#khr1').val();

    console.log(txt3d);

    console.log(usd);

    console.log(khr);

    if(txt3d != "" && txt3d.length == 3){

      if((usd != "") || (khr != "" && khr.length == 3)){

        var status = $('#checkbox-val').val();

        console.log('status is ' + status);
        
        // console.log($(this).parent().find('.upper').find('.checkbox-inline').find('.singleCheckbox').attr('checked'));
        
        // console.log($(this).parent().find('.lower').find('.checkbox-inline').find('.singleCheckbox').prop('checked'));
        
        if(status == 'upper'){

          // event.preventDefault();
          
          // swal("Oops!", "Checkbox checked!", "warning");

        }else if(status == 'lower'){

          event.preventDefault();

          console.log('status is false but still it is showing this message');
          
          swal("Oops!", "None of the checkbox is checked!", "warning");

        }else{

          event.preventDefault();

          swal("Oops!", "Please check any of the checkboxes before moving further.", "warning");          

        }

        // $('#3dform').submit();

          // event.preventDefault();
          
          // swal("Oops!", "Condition satisfied!", "warning"); 

      }else{

        event.preventDefault();

        swal("Oops!", "Please input either USD or KHR in valid format!", "warning");
      }

    }else{

      event.preventDefault();
           
      swal("Oops!", "Please input 3D field with minimum 3 digits between 101-999 before moving forward!", "warning");

    }

  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/3d-betform.blade.php */ ?>