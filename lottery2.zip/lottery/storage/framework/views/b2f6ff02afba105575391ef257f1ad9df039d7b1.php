<?php $__env->startSection('title'); ?>

Lottery | Dashboard

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="card-header"><strong><h2>Control CheckBox Visibility</h2></strong></div>
              <p>The list consists of all the users on the website.</p>   

               <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Checkbox Name</th>
                    <th>Status</th>
                    <th>Updated At</th>
                    <th>Toggle</th>
                  </tr>

                </thead>
                <tbody>

                </tbody>

                <tr>
                  <td>1.</td>
                   <td>A Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                 </tr>

                 <tr>
                  <td>2.</td>
                   <td>B Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                 </tr>

                 <tr>
                  <td>3.</td>
                   <td>C Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                 </tr>

                 <tr>
                  <td>4.</td>
                   <td>D Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                 </tr>

                 <tr>
                  <td>5.</td>
                   <td>H Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                 </tr>

                 <tr>
                  <td>6.</td>
                     <td>I Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                   </tr>

                   <tr>
                  <td>7.</td>
                   <td>N Field</td>
                   <td>None</td>
                   <td></td>
                   <td></td>

                 </tr>
                <tr>

                  <td>    

                    <label class="switch" id="switch">
        
                    <button id="checkbox" class="btn btn-primary" data-val="A">Hide Me</button>

                    <button id="checkboxs" class="btn btn-primary" style="display: none;">Hidden</button>
        
                  </label></td>
                  
   
                </tr>


              </table>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="<?php echo url('/');?>js/script.js"></script>

<script type="text/javascript">

  $(document).on('click', '#checkbox', function(){

    var data = $(this).data('val');
    
 $.ajax({

        url: "<?php echo URL::to('/');?>/dashboard/checkbox-status",

        headers: {
                    
          'X-CSRF-TOKEN':'<?php echo csrf_token() ?>',
                
        },

        type: 'POST',

        data: { 'status' : 0, 'data': data },

        success:function(response){

          var result = JSON.parse(response);

          // $('#addparentUsername').val(result.username);

          console.log(response);

          // console.log(result.level);

          // $('#myModal').modal('show');
        
        }

      });


  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/checkbox-status.blade.php */ ?>