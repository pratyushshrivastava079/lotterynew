<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function(){

// 	return redirect('/index');

// });

Route::get('/', 'UserController@index')->name('user');

Auth::routes();

Route::get('/index', function(){

	return redirect('/home');

});

Route::get('/home', 'HomeController@index')->name('home');

Route::post('/home/deleteuser', 'HomeController@deleteuser')->name('home');

Route::get('/dashboard', 'HomeController@dashboard')->name('home');

Route::get('/dashboard/userlist', 'HomeController@userlist')->name('home');

Route::get('/dashboard/add-users', 'HomeController@addusers')->name('home');

Route::get('/dashboard/2d-betform', 'HomeController@d2betform')->name('home');

Route::get('/dashboard/3d-betform', 'HomeController@d3betform')->name('home');

Route::post('/dashboard/add-users', 'HomeController@adduser')->name('home');

Route::post('/dashboard/2d-betform', 'HomeController@add2betform')->name('home');

Route::post('/dashboard/3d-betform', 'HomeController@add3betform')->name('home');

Route::post('/dashboard/getuserlist', 'HomeController@getuserlist')->name('home');

Route::get('/dashboard/adduserlevel/{id}', 'HomeController@getadduserlevel')->name('home');

Route::post('/dashboard/adduserlevel', 'HomeController@adduserlevel')->name('home');

Route::get('/dashboard/level/{id}', 'HomeController@level')->name('home');

Route::get('/dashboard/checkbox-status', 'HomeController@statuscheckbox')->name('home');

Route::post('/dashboard/checkbox-status', 'HomeController@updatecheckbox')->name('home');

