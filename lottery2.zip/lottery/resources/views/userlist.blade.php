@extends('layouts.website')


@section('title')

Lottery | Dashboard

@endsection

@section('content')


<!-- Bootstrap Modal to edit user details -->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title text-center">Add User</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
         <form id="addsubuser" method="POST">
              
              @csrf

              <div class="form-group">
              
                <label for="username">Username:</label>
              
                <input type="text" class="form-control" id="addusername" name="name">
              
              </div>

              <div class="form-group">
              
                <label for="fullname">Full Name:</label>
              
                <input type="text" class="form-control" id="addfullname" name="fullname">
              
              </div>

              <div class="form-group">
              
                <label for="email">Parent Username:</label>
              
                <input type="text" class="form-control" id="addparentUsername" name="parentUsername">
              
              </div>
              
              <div class="form-group">
              
                <label for="pwd">Password:</label>
              
                <input type="password" class="form-control" id="addpassword" name="password">
              
              </div>

              <div class="form-group">
    
                <label for="userlevel">Select User Level:</label>
                    
                    <select class="form-control" id="adduserlevel" name="userlevel">
    
                        <option value="2">Level B</option>
    
                        <option value="3">Level C</option>
    
                        <option value="4">Level D</option>
    
                    </select>
               
               </div>

              <div class="form-group">
              
                <label for="phone">Phone:</label>
              
                <input type="text" class="form-control" id="addphone" name="phone">
              
              </div>

              <div class="form-group">
              
                <label for="address">Address:</label>
              
                <input type="text" class="form-control" id="addaddress" name="address">
              
              </div>
              
              <button type="submit" class="btn btn-primary" id="subuser">Submit</button>
            
            </form>
      </div>
     <!--  <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div> -->
    </div>

  </div>
</div>
            <div class="card-header"><strong><h2>User List</h2></strong></div>
              <p>The list consists of all the users on the website.</p>            
              <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Add Users</th>
                    <th>Sr No</th>
                    <th>Username</th>
                    <th>Upper Level</th>
                    <th>Level of User</th>
                    <th>Created At</th>
                    <th>Action</th>
                  </tr>

                </thead>
                <tbody>
                    
                <?php
                

                // getting the page number and serial number

                $page = 1;

                if(isset($_GET['page'])){

                    if(is_numeric($_GET['page'])){

                        $page = $_GET['page'];

                        if($page != 1){

                            $page = $page * 10;

                            $page = $page - 9;
                        
                        }

                        }else{

                            $page = 1;
                        }

                    }else{

                        $page = 1;
                    }


                // getting status and deatails of users
                    foreach ($users as $user) { ;
                      // echo "<pre>";
                      // print_r($users);
                      // echo "</pre>";
                        if($user->email_verified_at == ''){

                            $status = "Pending";

                            $class= "warning";
                        
                        }else{

                            $status = "Confirm";

                            $class = "success";

                        }


                        if($user->userLevel == 1){

                            $type = "Level A";

                        }elseif($user->userLevel == 2){

                            $type = "Level B";

                        }elseif($user->userLevel == 3){

                            $type = "Level C";                            

                        }

                        if($user->accountType == 1){

                            $accountType = "Level A";

                        }elseif($user->accountType == 2){

                            $accountType = "Level B";

                        }elseif($user->accountType == 3){

                            $accountType = "Level C";                            

                        }


                        ?>


                  <tr>
                    <td><a href="<?php echo url('/');?>/dashboard/adduserlevel/{{ $user->id }}"><button class="btn btn-primary add-users" data-id="{{ $user->id }}" data-username="{{ $user->name }}" data-level="<?php echo $type;?>">+</button></a></td>

                    <td>{{ $page }}</td>
                
                    <td>{{ $user->name }}</td>
                
                    <td>{{ $accountType }}</td>

                    <td>{{ $type }}</td>
                
                    <td>{{ $user->created_at }}</td>
                
                    <td><span data-toggle="modal" data-target="#myModal"><i class="fa fa-pencil"></i></span>&nbsp&nbsp<span><i class="fa fa-trash" data-id="{{ $user->id }}"></i></span></td>
                
                  </tr>
                
                    <?php $page++;  }?>
                
                </tbody>
                {{ $users->links() }}

              </table>
                                      


@endsection



@section('footer')

<script type="text/javascript" src="<?php echo url('/');?>js/script.js"></script>

<script type="text/javascript">
  
  $(document).on('click', '.add-users', function(event){

    var userid = $(this).data('id');

    var username = $(this).data('username');

    var level = $(this).data('level');

    $.ajax({

        url: "<?php echo URL::to('/');?>/dashboard/getuserlist",

        headers: {
                    
          'X-CSRF-TOKEN':'<?php echo csrf_token() ?>',
                
        },

        type: 'POST',

        data: { 'userid': userid, 'username': username, 'level': level },

        success:function(response){

          var result = JSON.parse(response);

          $('#addparentUsername').val(result.username);

          // console.log(result.username);

          // console.log(result.level);

          $('#myModal').modal('show');
        
        }

      });

  });


  $(document).on('click', '#btnsubuser', function(event){

    event.preventDefault();

    var username = $('#addusername').val();

    var fullname = $('#addfullname').val();

    var parentUsername = $('#addparentUsername').val();

    var password = $('#addpassword').val();

    var userlevel = $('#adduserlevel option:selected').val();

    var phone = $('#addphone').val();

    var address = $('#addaddress').val();

    // var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

    // if (filter.test(sEmail)) {

    //   return true;

    // }else{

    //   return false;

    // }


    // console.log(username);
  
    // console.log(fullname);
  
    // console.log(parentUsername);
  
    // console.log(password);
  
    // console.log(userlevel);
  
    // console.log(phone);
  
    // console.log(address);

    $.ajax({

        url: "<?php echo URL::to('/');?>/dashboard/adduserlevel",

        headers: {
                    
          'X-CSRF-TOKEN':'<?php echo csrf_token() ?>',
                
        },

        type: 'POST',

        data: { 'username': username, 'fullname': fullname, 'parentUsername': parentUsername, 'password': password, 'userlevel': userlevel, 'phone': phone, 'address': address },

        success:function(response){

          var result = JSON.parse(response);

          $('#addparentUsername').val(result.username);

          // console.log(result.username);

          // console.log(result.level);

          $('#myModal').modal('show');
        
        }

      });


  });

</script>

@endsection