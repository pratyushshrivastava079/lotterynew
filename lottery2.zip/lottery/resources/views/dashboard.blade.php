@extends('layouts.website')


@section('title')

Lottery | Dashboard

@endsection

@section('content')


<!-- Bootstrap Modal to edit user details -->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

        
        
        
            <div class="card-header"><strong><h2>User List</h2></strong></div>
              <p>The list consists of all the users on the website.</p>            
              <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Email</th>
                    <th>Email Verification</th>
                    <th>Level of User</th>
                    <th>Created At</th>
                    <th>Action</th>
                  </tr>

                </thead>
                <tbody>
                    
                <?php

                // getting the page number and serial number

                $page = 1;

                if(isset($_GET['page'])){

                    if(is_numeric($_GET['page'])){

                        $page = $_GET['page'];

                        if($page != 1){

                            $page = $page * 10;

                            $page = $page - 9;
                        
                        }

                        }else{

                            $page = 1;
                        }

                    }else{

                        $page = 1;
                    }


                // getting status and deatails of users

                    foreach ($users as $user) { ;

                        if($user->email_verified_at == ''){

                            $status = "Pending";

                            $class= "warning";
                        
                        }else{

                            $status = "Confirm";

                            $class = "success";

                        }


                        if($user->accountType == 1){

                            $type = "Level A";

                        }elseif($user->accountType == 2){

                            $type = "Level B";

                        }elseif($user->accountType == 3){

                            $type = "Level C";                            

                        }


                        ?>


                  <tr>
                    <td>{{ $page }}</td>
                
                    <td>{{ $user->email }}</td>
                
                    <td><span class="{{ $class }}">{{ $status }}</span></td>
                
                    <td>{{ $type }}</td>
                
                    <td>{{ $user->created_at }}</td>
                
                    <td><span data-toggle="modal" data-target="#myModal"><i class="fa fa-pencil"></i></span>&nbsp&nbsp<span><i class="fa fa-trash" data-id="{{ $user->id }}"></i></span></td>
                
                  </tr>
                
                    <?php $page++;  }?>
                
                </tbody>
                {{ $users->links() }}

              </table>
                                      


@endsection



@section('footer')

<script type="text/javascript" src="js/script.js"></script>
@endsection