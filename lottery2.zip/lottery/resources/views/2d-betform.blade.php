@extends('layouts.website')


@section('title')

Lottery | Dashboard | 2D Betform

@endsection

@section('content')

            <div class="card-header"><h2>Form</h2></div>

            <p>2D bet form for different level users.</p>

           @if(!isset($errors)) 
                {{ $errors }}

            @endif

            @if ($errors->any())
              
              <div class="alert alert-danger">
                
                <ul>
              
                  @foreach ($errors->all() as $error)
                
                    <li>{{ $error }}</li>
                
                  @endforeach
                
                </ul>
              
              </div>
          
            @endif

            @if(isset( $batch ))

            <button class="btn btn-primary" id="pdf">Print</button>

              <table class="table table-hover table-respponsive" id="example">
              
                <thead>
              
                  <tr>
              
                    <th>2D</th>
              
                    <th>USD</th>
              
                    <th>KHR</th>
              
                    <th>PO</th>
              
                  </tr>
              
                </thead>
              
              <tbody>
              
              @foreach ($batch as $bat)
            
                  <tr>
              
                    <td>{{ $bat->d2_value }}</td>
              
                    <td>{{ $bat->usd_value }}</td>
              
                    <td>{{ $bat->khr_value }}</td>

                    <td>{{ $bat->checkbox_value }}</td>
              
                  </tr>

              @endforeach

              <tr>
                
                <td>Total</td>
                <td>{{ $usd }}</td>
                <td>{{ $khr }}</td>
                <td>{{ $time }}</td>

              </tr>
              
                </tbody>
              
              </table>
              
            @endif


            @if(isset($successmsg))

              <div class="alert alert-success"> {{ $successmsg }}</div>

            @endif
            
            @if( Session::has( 'errormessage' ))

              <div class="alert alert-success"> {{ Session::get( 'errormessage' ) }}</div>

            @endif

            <button type="submit" class="btn btn-primary" id="add">+ Add More Fields</button>

            <form action="<?php echo url('/');?>/dashboard/2d-betform" method="POST">
              
              @csrf

              <input type="hidden" id="lastlevel" value="1" />

              <div class="first-line">

                <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div>

                <div class="form-group">
                
                  <label for="2d">2D:</label>
                
                  <input type="text" id="2d1" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed">
                
                </div>

                 <div class="form-group">
                
                  <label for="usd">USD:</label>
                
                  <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) ">
                
                </div>

                <div class="form-group">
                
                  <label for="khr">KHR:</label>
                
                  <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )">
                
                </div>

              </div>

              <div class="radio">

                <label class="radio-inline"><input type="radio" name="optradio" value="5OD">5 OD</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="5S">5 S</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="10S">10 S</label>

              </div>

              <div class="checkbox">
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="A" name="checkbox[]">A</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="B" name="checkbox[]">B</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="C" name="checkbox[]">C</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="D" name="checkbox[]">D</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="H" name="checkbox[]">H</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="I" name="checkbox[]">I</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="N" name="checkbox[]">N</label>

              </div>

              <div class="checkbox">
                
                <label class="checkbox-inline"><input type="checkbox" id="l23" value="l23" class="checkLevel" name="level_checkbox[]">L 23</label>
                
                <label class="checkbox-inline"><input type="checkbox" id="l29" value="l29" class="checkLevel" name="level_checkbox[]">L 29</label>
                
              </div>

              <button type="submit" class="btn btn-default">Submit</button>
            
            </form>            

            <br/>

@endsection



@section('footer')

<script type="text/javascript" src="<?php echo url('/');?>/js/script.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>

<script src="<?php echo url('/');?>/js/tableHTMLExport.js"></script>

<script>
  
  $(document).on('click', '#pdf' ,function(){
    $("#example").tableHTMLExport({type:'pdf',filename:'report.pdf'});
  });

</script>

<script type="text/javascript">
  
  $(document).ready(function(){

    $('#add').click(function(event){

      var level = $('#lastlevel').val();

      console.log("level is " + level);

      var txt2d = $('#2d'+level).val();

      var usd = $('#usd'+level).val();

      var khr = $('#khr'+level).val();

      console.log("2d value is " + txt2d);

      if( txt2d != '' && usd != '' && khr != '' ){

        var radioValue = $("input[name='optradio']:checked").val();
        
        if(radioValue){
        
          console.log("Your are a - " + radioValue);
          
          txt2d = parseInt(txt2d);

          if(radioValue == '5OD'){

            if(level > '4'){

               swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 2;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>');

            }

          }else if(radioValue == '5S'){

            if(level > '4'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 2;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

          }else if(radioValue == '10S'){

             if(level > '9'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 1;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 
    
            }

          }else{
            // console.log('nothing matched');
            swal("Oops!", "Please handle checkbox validation error!", "warning");
            // nothing goes here all checkbox conditions have been checked above
          }

          }else{

            console.log("radioValue is not selected" );

          }  

        }else{

          swal("Oops!", "Please input aal fields before adding extra fields!", "warning");
       
        }

    });

  });

  $(document).on('click', '.radio-inline', function(){

      $('#lastlevel').val('1');

      $('.first-line').html(' <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d1" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) "> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )"> </div>');

    });


  $(document).on('keypress', '.2d', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

       if (event.which > 47 &&  event.which < 58  && targetValue.length < 2) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if (result < 0 || result > 99) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }
       
       else {
       
           event.preventDefault();
       
       }


    });

  $(document).on('keypress', '.usd', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        console.log(targetValue);

        console.log(event.keyCode);

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

        // if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
          
        //   event.preventDefault();
        
        // }else{
        
        if (event.which > 47 &&  event.which < 58  && targetValue.length < 6) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if (result < 0 || result > 99) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }

       
       else {
       
           event.preventDefault();
       
       }

    });

  $(document).on('click', '.checkLevel', function(){

    var checked = $(this).prop('checked');

    if(checked){

      var checkboxValue = $(this).val();

      console.log(checkboxValue);

      if(checkboxValue == 'l23'){

        $('#l29').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }else if(checkboxValue == 'l29'){

        $('#l23').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }

    }

  });


  $(document).on('click', '.singleCheckbox', function(){

    var checked = $(this).prop('checked');

    if(checked){

        $('#l29').prop('checked', false);

        $('#l23').prop('checked', false);

    }

  });

  $(document).on('click', '.btn-default', function(event){

    // alert('asasas');

    var txt2d = $('#2d1').val();

    var usd = $('#usd1').val();

    var khr = $('#khr1').val();

    console.log(txt2d);

    console.log(usd);

    console.log(khr);

    if(txt2d == "" || usd == "" || khr == ""){

      event.preventDefault();
         
      swal("Oops!", "Please input all fields before moving forward!", "warning");

    }else{


    }

  });

</script>

@endsection