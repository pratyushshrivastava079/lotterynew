$(function(){


	$(document).on('click', '.radio-currency', function(){

		var id = $(this).data('id');

		console.log(id);

		if( id == "USD"){

			$('.span-id').html('<input type="text" name="txtval" placeholder="txtval" id="txtval"><input type="text" name="usd" placeholder="USD value" id="USD">');

		}else if( id == 'KHR'){

			$('.span-id').html('<input type="text" name="txtval" placeholder="txtval" id="txtval"><input type="text" name="khr" placeholder="KHR value" id="KHR">');
		}

	});

	$(document).on('click', '.p-btn', function(){

		var value = $(this).data('val');

		console.log(value);

		var add = 0;

		add = $('#txtval').val();

		if(add > 0){
	
			console.log('greater than zero' + add);
			
		}else{

			alert();

		}

		add = add + parseInt(value);

		console.log(add);

		$('#txtval').val(add);

	});


});