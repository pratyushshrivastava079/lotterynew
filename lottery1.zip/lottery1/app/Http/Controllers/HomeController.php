<?php

namespace App\Http\Controllers;

use App\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $users = DB::table('users')->paginate(10);

        // print_r($users);

        return view('home', ['users' => $users]);
    }

    public function deleteuser(Request $request){

        if ($request->isMethod('post')) {

            $data = $request->all(); // This will get all the request data.

            print_r($data); // This will dump and die

            $id = $data['userid'];

            $user = DB::table('users')->where('id', '=', $id)->delete();    
        
            // print_r(User);

            if($user){

                echo "user successfully deleted"; 
            
            }else{

                echo "user was not successfully deleted";

            }

        }else{

            echo json_encode(array('status' => 'error', 'message' => 'the input request is suspected.'));
        }

    }


    public function dashboard(){

        $users = DB::table('users')->paginate(10);

        return view('dashboard', ['users' => $users]);

    }

     public function userlist(){

        $users = DB::table('users')->join('parent_level', 'users.id', '=', 'parent_level.user_id')->paginate(10);

        return view('userlist', ['users' => $users]);

    }

     public function addusers(){

        return view('add-users');

    }

    public function adduser(Request $request){

        $request->validate([
        
            'name' => 'required',
        
            'fullname' => 'required',

            'email' => 'required|email|unique:users,email',
            
            'password' => 'required|min:8',

            'phone' => 'required|max:13',

            'address' => 'required',

            'balanceUSD' => 'required',

            'balanceKHR' => 'required',
            
            'userlevel' => 'required',

            'userpercent' => 'required',
        
        ]);


        // print_r($validatedData);

        $username = $request->input('name');

        $fullname = $request->input('fullname');
        
        $email = $request->input('email');
        
        $password = $request->input('password');
        
        $userlevel = $request->input('userlevel');
        
        $balanceUSD = $request->input('balanceUSD');
        
        $balanceKHR = $request->input('balanceKHR');
        
        $userpercent = $request->input('userpercent');
        
        $phone = $request->input('phone');
        
        $address = $request->input('address');

        $user  = User::create([
            'name' => $username,
            'email' => $email,
            'password' => Hash::make($password),
        ]);

        if($user){

            $userinfo = DB::table('user_info')->insert([
            
            'userid' => $user->id,
            'fullname' => $fullname,
            'user_level' => $userlevel,
            'balanceUSD' => $balanceUSD,
            'balanceKHR' => $balanceKHR,
            'userpercent' => $userpercent,
            'phone' => $phone,
            'address' => $address
            
            ]);

            if($userinfo){

                $successmsg = "Congrats. User added to the list.";

                return back()->with('successmsg' , $successmsg);
                
            }else{

                $successmsg = "Oops! Some error occured with form validation.";

                return back()->with('errormsg' , $errormsg);

            }

        }

    }


    public function getuserlist(Request $request){

        $userid = $request->input('userid');
        
        $username = $request->input('username');

        $level = $request->input('level');

        // echo "userid is " . $userid;

        $user = DB::table('users')->where('id', '=', $userid)->get();

        // print_r($user);

        if($user){

            echo json_encode(array('status' => 'true', 'data' => $user[0], 'username' => $username, 'level' => $level));

        }else{

            echo json_encode(array('status' => 'false', 'data' => 'Oops! Unable to add users.'));

        }

    }

    public function adduserlevel(Request $request){

        $validatedData = $request->validate([
        
            'name' => 'required | unique:users',
        
            'fullname' => 'required',

            'password' => 'required',

            'userlevel' => 'required',

            'phone' => 'required',

            'address' => 'required'
        
        ]);

        if($validatedData){

            $username = $request->input('name');
    
            $fullname = $request->input('fullname');
    
            $parentUsername = $request->input('parentUsername');
    
            $password = $request->input('password');
    
            $userlevel = $request->input('userlevel');
    
            $phone = $request->input('phone');
    
            $address = $request->input('address');

            // echo $username;

            // echo $fullname;

            // echo $parentUsername;

            // echo $password;

            // echo $userlevel;

            // echo $phone;

            // echo $address;

            // die();

        //      $user  = User::create([
        //     'name' => $username,
        //     'email' => $username,
        //     'added_by' => $parentUsername,
        //     'accountType' => $userlevel,
        //     'password' => Hash::make($password),
        // ]);
            $user = DB::table('users')->insertGetId([

                'name' => $username,
                'email' => $username,
                'added_by' => $request->session()->get('added_by'),
                'accountType' => $userlevel,
                'password' => Hash::make($password),

            ]);

            // print_r($user);

            // die();

        if($user){

            $userinfo = DB::table('user_info')->insert([
            
            'userid' => $user,
            'fullname' => $fullname,
            'user_level' => $userlevel,
            'balanceUSD' => 0,
            'balanceKHR' => 0,
            'userpercent' => 0,
            'phone' => $phone,
            'address' => $address
            
            ]);

            if($userinfo){

                $userinfos = DB::table('parent_level')->insert([
            
                'user_id' => $parentUsername,
                'bottom_id' => $user,
                'userLevel' => $userlevel,
                
                ]);

                if($userinfos){

                    $successmsg = "Congrats. User added to the list.";

                    return back()->with('message' , $successmsg);
                
                }else{

                    $successmsg = "Oops! Some error occured with form validation.";

                    return back()->with('message' , $errormsg);

                }

            }else{

                $successmsg = "Oops! Some error occured with form validation.";

                return back()->with('message' , $errormsg);

            }

        }

        }else{

            return back()->with('error','Unable to post news.');
        }
    }

    public function getadduserlevel($id, Request $request){

        $user = DB::table('users')->where('id', '=', $id)->get();

        // print_r($user[0]);

        $request->session()->put('added_by', $user[0]->name);

        return view('adduserlevel', ['user' => $user[0]]);

    }

    public function level($id){

        $user = DB::table('users')->where('accountType', '=', $id)->paginate(10);

        if(count($user) > 0){

            return view('level', ['users' => $user]);

        }else{

            return view('level', ['error' => 'No users were found in the list.']);
            
        }

    }


    public function getlevel(){

         return view('level');
    }

    public function d2betform(){

        return view('2d-betform');

    }

    public function d3betform(){

         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();

        return view('3d-betform', ['select' => $select]);

    }

    public function add3betform(Request $request){

        $d2txt = $request->input('txt3d');
        
        $usd = $request->input('usd');
        
        $khr = $request->input('khr');
        
        $radioValue = $request->input('optradio');

        $checkboxValue = $request->input('checkbox');
        
        $levelValue = $request->input('level_checkbox');

        // print_r($d2txt);

        // // print_r($usd);
        
        // // print_r($khr);

        // print_r($radioValue);

        // print_r($checkboxValue);

        // print_r($levelValue);
        
        $count_d2txt = count($d2txt);

        $count_usd = count($usd);

        $count_khr = count($khr);

        $user = auth()->user();

        $userId = $user->id;

        $array = array();

        $arry = array();

        $finalarray = array();

        $arr = array();

        $batchno = "";

        $usdbal = 0;

        $khrbal = 0;

        $ckvalue = $checkboxValue;
        
        $lvvalue = $levelValue;

        if($checkboxValue != ''){

            $checkboxValue = implode(',', $checkboxValue);

            // var_dump($checkboxValue);
        }

        if($levelValue != ''){

            $levelValue = implode(',', $levelValue);

            // var_dump($levelValue);

        }

        $batch = DB::table('2dbetform')->where('user_id', '=', $userId)->orderBy('batch', 'desc')->limit(1)->get();

            if(count($batch) > 0){

                $batchno = $batch[0]->batch;

                $batchno = $batchno + 1;
                
            }else{

                $batchno = 0;
            }

            // print_r($count_d2txt);

            // die();

            if( $count_d2txt == 1 && ($count_usd == 1 || $count_khr == 1 )){

               if($radioValue == '5L' || $radioValue == '5C' || $radioValue == '5R'){

                $newval = $d2txt;

                $newval = implode($d2txt, ',' );

                // print_r($newval);

                // die();
                    
                for($i = 0 ; $i < 5 ; $i++){

                    if($radioValue == '5L'){

                        $newval[0] = $newval[0]+1;

                        // var_dump($newval);


                    }elseif($radioValue == '5C'){

                        $newval[1] = $newval[1]+1;

                        var_dump($newval);

                    }elseif($radioValue == '5R'){

                        $newval[2] = $newval[2]+1;

                        // var_dump($newval);

                    }else{}

                    $array = array(

                        'user_id' => $userId,

                        'd3_value' => $newval,

                        'usd_value' => $usd[0],

                        'khr_value' => $khr[0],

                        'radio_value' => $radioValue,

                        'checkbox_value' => $checkboxValue,

                        'level_value' => $levelValue,

                        'level' => 0,

                        'batch' => $batchno

                    );

                    $insert = DB::table('3dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;
                }
                        
                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('3dbetform')->where('id', '=', $arrid[$j])->get();

                        }

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }

            }elseif($radioValue == '10L' || $radioValue == '10C' || $radioValue == '10R'){

                $newval = $d2txt;

                $newval = implode($d2txt, ',' );

                for($i = 0 ; $i < 10 ; $i++){

                    if($radioValue == '10L'){

                        $newval[0] = $newval[0]+1;

                        // var_dump($newval);

                    }elseif($radioValue == '10C'){

                        $newval[1] = $newval[1]+1;

                        // var_dump($newval);

                    }elseif($radioValue == '10R'){

                        $newval[2] = $newval[2]+1;

                        // var_dump($newval);

                    }else{}

                    $array = array(

                        'user_id' => $userId,

                        'd3_value' => $newval,

                        'usd_value' => $usd[0],

                        'khr_value' => $khr[0],

                        'radio_value' => $radioValue,

                        'checkbox_value' => $checkboxValue,

                        'level_value' => $levelValue,

                        'level' => 0,

                        'batch' => $batchno

                    );

                    $insert = DB::table('3dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;
                }
                        
                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('3dbetform')->where('id', '=', $arrid[$j])->get();

                        }
                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }


            }elseif($radioValue == '5OD'){

                $value = array();

                $newval = $d2txt;

                $newval = implode($d2txt, ',' );

                $str = $newval;

                $n = strlen($newval); 

                $newval  = str_split($newval);

                $value = $this->pc_permute($newval);
    
                $d3txtfinal  = array();

                for($i = 0 ; $i < count($value) ; $i++){

                    array_push($d3txtfinal, implode($value[$i]));
                }

                for($j = 0 ; $j < count($d3txtfinal) ; $j++){

                    $array = array(

                    'user_id' => $userId,

                    'd3_value' => $d3txtfinal[$j],

                    'usd_value' => $usd[0],

                    'khr_value' => $khr[0],

                    'radio_value' => $radioValue,

                    'checkbox_value' => $checkboxValue,

                    'level_value' => $levelValue,

                    'level' => 0,

                    'batch' => $batchno

                );

                $insert = DB::table('3dbetform')->insertGetId($array);

                    $arrid[$j] = $insert;
                }

                // die();
                        
                    if($arrid){

                        for($k = 0; $k < count($arrid); $k++){

                            $data[$k] = DB::table('3dbetform')->where('id', '=', $arrid[$k])->get();

                        }
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();

                        return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }


            }elseif($radioValue == NULL){

                $array = array(

                    'user_id' => $userId,

                    'd3_value' => $d2txt[0],

                    'usd_value' => $usd[0],

                    'khr_value' => $khr[0],

                    'radio_value' => $radioValue,

                    'checkbox_value' => $checkboxValue,

                    'level_value' => $levelValue,

                    'level' => 0,

                    'batch' => $batchno

                );

                $insert = DB::table('3dbetform')->insertGetId($array);

                if($insert){

                    $data = DB::table('3dbetform')->where('id', '=', $insert)->get();

                    $successmsg = "Congrats! Your bet has been successfully posted.";

                     $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                                
                    return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
                                
                    return back()->with('errormessage', $errormsg);
        
                }
            }

        }else{  

             if($radioValue == '5L' || $radioValue == '5C' || $radioValue == '5R' || $radioValue == '5OD'){

                $newval = $d2txt;

                $newval = implode($d2txt, ',' );

                // print_r($newval[0]);

                // die();
                    

                    if($radioValue == '5L'){

                        $newval[0] = $newval[0]+1;

                        // var_dump($newval);


                    }elseif($radioValue == '5C'){

                        $newval[1] = $newval[1]+1;

                        // var_dump($newval);

                    }elseif($radioValue == '5R'){

                        $newval[2] = $newval[2]+1;

                        // var_dump($newval);

                    }else{}

                    $newval = explode(',', $newval);

                    // echo $newval[0];
                    // die();

                    for($i = 0 ; $i < count($newval) ; $i++){

                    $array = array(

                        'user_id' => $userId,

                        'd3_value' => $newval[$i],

                        'usd_value' => $usd[$i],

                        'khr_value' => $khr[$i],

                        'radio_value' => $radioValue,

                        'checkbox_value' => $checkboxValue,

                        'level_value' => $levelValue,

                        'level' => $i,

                        'batch' => $batchno

                    );


                    $insert = DB::table('3dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;

                }

                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('3dbetform')->where('id', '=', $arrid[$j])->get();

                        }

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }

                // }

            }elseif($radioValue == '10L' || $radioValue == '10C' || $radioValue == '10R'){

                $newval = $d2txt;

                $newval = implode($d2txt, ',' );


                    if($radioValue == '10L'){

                        $newval[0] = $newval[0]+1;

                        // var_dump($newval);

                    }elseif($radioValue == '10C'){

                        $newval[1] = $newval[1]+1;

                        // var_dump($newval);

                    }elseif($radioValue == '10R'){

                        $newval[2] = $newval[2]+1;

                        // var_dump($newval);

                    }else{}

                for($i = 0 ; $i < 10 ; $i++){
                    $array = array(

                        'user_id' => $userId,

                        'd3_value' => $newval[$i],

                        'usd_value' => $usd[$i],

                        'khr_value' => $khr[$i],

                        'radio_value' => $radioValue,

                        'checkbox_value' => $checkboxValue,

                        'level_value' => $levelValue,

                        'level' => $i,

                        'batch' => $batchno

                    );

                    $insert = DB::table('3dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;
                }
                        
                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('3dbetform')->where('id', '=', $arrid[$j])->get();

                        }
                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }


            }elseif($radioValue == NULL){

                $array = array(

                    'user_id' => $userId,

                    'd3_value' => $d2txt[0],

                    'usd_value' => $usd[0],

                    'khr_value' => $khr[0],

                    'radio_value' => $radioValue,

                    'checkbox_value' => $checkboxValue,

                    'level_value' => $levelValue,

                    'level' => 0,

                    'batch' => $batchno

                );

                $insert = DB::table('3dbetform')->insertGetId($array);

                if($insert){

                    $data = DB::table('3dbetform')->where('id', '=', $insert)->get();

                    $successmsg = "Congrats! Your bet has been successfully posted.";

                     $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                                
                    return view('3d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
                                
                    return back()->with('errormessage', $errormsg);
        
                }
            }

        }

    }


        public function pc_permute($items, $perms = array( )) {
    if (empty($items)) {
        $return = array($perms);
    }  else {
        $return = array();
        for ($i = count($items) - 1; $i >= 0; --$i) {
             $newitems = $items;
             $newperms = $perms;
         list($foo) = array_splice($newitems, $i, 1);
             array_unshift($newperms, $foo);
             $return = array_merge($return, $this->pc_permute($newitems, $newperms));
         }
    }
    return $return;
} 

public function permute($str, $l, $r, $arry) 
{ 
    // $arry = array();


    // die();

    if ($l == $r){ 
    
    // echo gettype($arry);
        array_push($arry, $str);

        // print_r($arry);

    }else
    { 
        for ($i = $l; $i <= $r; $i++) 
        { 
            $str = $this->swap($str, $l, $i); 
            $this->permute($str, $l + 1, $r, $arry); 
            $str = $this->swap($str, $l, $i); 
        } 
    }

    return $arry;   

} 

public function swap($a, $i, $j) 
{ 
    $temp; 
    $charArray = str_split($a); 
    $temp = $charArray[$i] ; 
    $charArray[$i] = $charArray[$j]; 
    $charArray[$j] = $temp; 
    return implode($charArray); 
} 



    public function add2betform(Request $request){

        $d2txt = $request->input('txt2d');
        
        $usd = $request->input('usd');
        
        $khr = $request->input('khr');
        
        $radioValue = $request->input('optradio');

        $checkboxValue = $request->input('checkbox');
        
        $levelValue = $request->input('level_checkbox');

        $count_d2txt = count($d2txt);

        $count_usd = count($usd);

        $count_khr = count($khr);

        $user = auth()->user();

        $userId = $user->id;

        $array = array();

        $finalarray = array();

        $batchno = "";

        $usdbal = 0;

        $khrbal = 0;

         $ckvalue = $checkboxValue;
        
        $lvvalue = $levelValue;


        if($checkboxValue != ''){

            $checkboxValue = implode(',', $checkboxValue);
        }

        if($levelValue != ''){

            $levelValue = implode(',', $levelValue);

        }

            $batch = DB::table('2dbetform')->where('user_id', '=', $userId)->orderBy('batch', 'desc')->limit(1)->get();

            if(count($batch) > 0){

                $batchno = $batch[0]->batch;

                $batchno = $batchno + 1;
                
            }else{

                $batchno = 0;
            }

            if( $count_d2txt == 1 && ($count_usd == 1 || $count_khr == 1 )){

               if($radioValue == '5OD' || $radioValue == '5S'){

                 $newval = $d2txt[0];


                 for($i = 0 ; $i < 5 ; $i++){

                    if($radioValue == '5OD'){
                        // echo gettype($newval);
                        // print_r($newval);
                        // die();
                        $newval = $newval+2;


                    }elseif($radioValue == '5C'){

                        $newval = $newval+1;

                    }else{}

                    // print_r($newval);

                    // die();

                        $array = array(

                            'user_id' => $userId,

                            'd2_value' => $newval,

                            'usd_value' => $usd[0],

                            'khr_value' => $khr[0],

                            'radio_value' => $radioValue,

                            'checkbox_value' => $checkboxValue,

                            'level_value' => $levelValue,

                            'level' => $i,

                            'batch' => $batchno

                        );

                        $insert = DB::table('2dbetform')->insertGetId($array);

                        $arrid[$i] = $insert;

                        // print_r($array);
                }
                        // die();
                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('2dbetform')->where('id', '=', $arrid[$j])->get();

                        }

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('2d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }


            }elseif($radioValue == '10S'){

                $newval = $d2txt;

                 for($i = 0 ; $i < 10 ; $i++){

                    if($radioValue == '10S'){

                        $newval = $newval+2;

                    }else{}

                        $array = array(

                            'user_id' => $userId,

                            'd2_value' => $newval,

                            'usd_value' => $usd[0],

                            'khr_value' => $khr[0],

                            'radio_value' => $radioValue,

                            'checkbox_value' => $checkboxValue,

                            'level_value' => $levelValue,

                            'level' => $i,

                            'batch' => $batchno

                        );

                        $insert = DB::table('2dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;
                }
                        
                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('2dbetform')->where('id', '=', $arrid[$j])->get();

                        }

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('2d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }

                 }elseif($radioValue == NULL){

                             $newval = $d2txt;

                        $array = array(

                            'user_id' => $userId,

                            'd2_value' => $newval[0],

                            'usd_value' => $usd[0],

                            'khr_value' => $khr[0],

                            'radio_value' => $radioValue,

                            'checkbox_value' => $checkboxValue,

                            'level_value' => $levelValue,

                            'level' => 0,

                            'batch' => $batchno

                        );

                        $insert = DB::table('2dbetform')->insertGetId($array);

                    $arrid = $insert;
                }
                        
                    if($arrid){

                        // for($j = 0; $j < count($arrid); $j++){

                            $data = DB::table('2dbetform')->where('id', '=', $arrid)->get();

                        // }

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('2d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }

}else{

// 





 if($radioValue == '5C' || $radioValue == '5OD'){


                $newval = $d2txt;

                $newval = implode($d2txt, ',' );


                 for($i = 0 ; $i < 5 ; $i++){

                    if($radioValue == '5OD'){

                        $newval = $newval+2;


                    }elseif($radioValue == '5C'){

                        $newval = $newval+1;

                    }else{}

                    $newval = explode(',', $newval);

                    // echo $newval[0];
                    // die();

                    for($i = 0 ; $i < count($newval) ; $i++){
                    $array = array(

                        'user_id' => $userId,

                        'd2_value' => $newval[$i],

                        'usd_value' => $usd[$i],

                        'khr_value' => $khr[$i],

                        'radio_value' => $radioValue,

                        'checkbox_value' => $checkboxValue,

                        'level_value' => $levelValue,

                        'level' => $i,

                        'batch' => $batchno

                    );


                    $insert = DB::table('2dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;

                }

                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('2dbetform')->where('id', '=', $arrid[$j])->get();

                        }

                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('2d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }

                }

            }elseif($radioValue == '10S'){

                $newval = $d2txt;

                $newval = implode($d2txt, ',' );

                                    $newval = explode(',', $newval);


                for($i = 0 ; $i < 10 ; $i++){

                    $array = array(

                        'user_id' => $userId,

                        'd2_value' => $newval[$i],

                        'usd_value' => $usd[$i],

                        'khr_value' => $khr[$i],

                        'radio_value' => $radioValue,

                        'checkbox_value' => $checkboxValue,

                        'level_value' => $levelValue,

                        'level' => $i,

                        'batch' => $batchno

                    );

                    $insert = DB::table('2dbetform')->insertGetId($array);

                    $arrid[$i] = $insert;
                }
                        
                    if($arrid){

                        for($j = 0; $j < count($arrid); $j++){

                            $data[$j] = DB::table('2dbetform')->where('id', '=', $arrid[$j])->get();

                        }
                         $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();
                        
                        $successmsg = "Congrats! Your bet has been successfully posted.";

                        return view('2d-betform', ['successmsg' => $successmsg, 'data' => $data, 'checkboxvalue' => $ckvalue, 'levelValue' => $lvvalue, 'select' => $select]);

                    }else{

                        $errormsg = "Sorry! Error placing bet. Please try again.";
            
                        return back()->with('errormessage', $errormsg);
        
                    }
            }



















    // 





}







         }


        public function statuscheckbox(){

            $select =  DB::table('control_boxes')
                     ->select('*')
                     ->where('admin_id', '=', 1)
                     ->get();

            // print_r($select);

            return view('checkbox-status', ['data' => $select ]);

        }   


        public function updatecheckbox(Request $request){

            $status = $request->input('status');
            
            $data = $request->input('data');

            $userId = Auth::id();

            if($data == "A"){             

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['A_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'B'){             

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['B_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'C'){         

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['C_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == "D"){              

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['D_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'H'){             

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['H_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }               

            }elseif($data == 'I'){

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['I_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'N'){            

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['N_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

             }elseif($data == 'l19'){            

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['l19_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }
                

             }elseif($data == 'l22'){            

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['l22_status' => 1 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }    


            }else{


            }

        }


        public function deletecheckbox(Request $request){

            $status = $request->input('status');
            
            $data = $request->input('data');

            $userId = Auth::id();

            if($data == "A"){             

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['A_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'B'){             

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['B_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'C'){         

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['C_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == "D"){              

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['D_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'H'){             

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['H_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }               

            }elseif($data == 'I'){

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['I_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

            }elseif($data == 'N'){            

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['N_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }

             }elseif($data == 'l19'){            

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['l19_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }
                

             }elseif($data == 'l22'){            

                $formvalid = DB::table('control_boxes')->where('admin_id', 1)->update(['l22_status' => 0 ]);

                if($formvalid){

                    $successmsg = "Congrats! Checkbox hidden from form.";
                    
                    return json_encode(array('successmsg' => $successmsg, 'status' => 1 ));

                }else{

                    $errormsg = "Sorry! Error placing bet. Please try again.";
        
                    return json_encode(array('errormsg' => $errormsg, 'status' => 0 ));

                }    


            }else{


            }

        }

}
