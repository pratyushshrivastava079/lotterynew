<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- <title><?php echo e(config('app.name', 'Lottery System')); ?></title> -->


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Google font-->
    <link href="https://fonts.proxy.ustclug.org/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"><link href="https://fonts.proxy.ustclug.org/css?family=Quicksand:500,700" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/bootstrap.min.css">
    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo url('/');?>css/waves.min.css" type="text/css" media="all">
    <!-- feather icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/feather.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/icofont.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/font-awesome.min.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo url('/');?>css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <!-- <link rel="dns-prefetch" href="//fonts.gstatic.com"> -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css"> -->

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom-style.css')); ?>" rel="stylesheet">


    <!-- <?php echo $__env->yieldContent('title'); ?> -->


</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Project
                    <!-- <?php echo e(config('app.name', 'Lottery System')); ?> -->
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">

            <div class="container card">

                <div class="row card-body">
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 card">
            
            <div class="card-header"><strong>Menu</strong></div>

            <hr/>

            <ul>
                <br/>
                <li><i class="fa fa-tachometer" aria-hidden="true"></i>&nbsp&nbsp&nbsp<a href="/dashboard">Dashboard</a></li>
                <hr/>
                <li id="clickme"><i class="fa fa-newspaper-o" aria-hidden="true"></i>&nbsp&nbsp&nbspUsers</li>
                <hr/>
                <ol class="style-ol">
                    <li><a href="/dashboard/add-users">Add Users</a></li>
                <hr/>
                    <li><a href="/dashboard/userlist">User List</a>

                        <ul>
                            
                            <li><a href="/dashboard/level/1">Level A</a></li>
                            <li><a href="/dashboard/level/2">Level B</a></li>
                            <li><a href="/dashboard/level/3">Level C</a></li>
                            <li><a href="/dashboard/level/4">Level D</a></li>

                        </ul>

                    </li>
                <hr/>
                   
                </ol>
                <hr/>

                <li><i class="fa fa-list" aria-hidden="true"></i>&nbsp&nbsp&nbsp<a href="/dashboard/category">Forms</a></li>
                <hr/>
                <ol class="style-ol">
                    
                    <li><i class="fa fa-list-alt" aria-hidden="true"></i>&nbsp&nbsp&nbsp<a href="/dashboard/2d-betform">2D Bet Form</a></li>

                    <hr/>
                    
                    <li><i class="fa fa-gear" aria-hidden="true"></i>&nbsp&nbsp&nbsp<a href="/dashboard/3d-betform">3D Bet Form</a></li>
                    
                    <br/>

                </ol>

                 <li><i class="fa fa-list" aria-hidden="true"></i>&nbsp&nbsp&nbsp<a href="#">User Controls</a></li>
                <hr/>
                <ol class="style-ol">
                    
                    <li><i class="fa fa-list-alt" aria-hidden="true"></i>&nbsp&nbsp&nbsp<a href="/dashboard/checkbox-status">Checkboxes status</a></li>

                    <hr/>
                    
                    <br/>

                </ol>
            </ul>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 card">

                    <?php echo $__env->yieldContent('content'); ?>


                </div>

                </div>
            
        </main>


        <?php echo $__env->yieldContent('footer'); ?>

    </div>
</body>
</html>

<?php /* /var/www/html/lottery/resources/views/layouts/website.blade.php */ ?>