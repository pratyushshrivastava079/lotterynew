<?php $__env->startSection('title'); ?>

Lottery | Dashboard

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div> -->



<!-- Bootstrap Modal to edit user details -->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


            <h2>User List</h2>
              <p>The list consists of all the users on the website.</p>            
              <table class="table table-striped table-responsive">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Email</th>
                    <th>Email Verification</th>
                    <th>Level of User</th>
                    <th>Created At</th>
                    <th>Action</th>
                  </tr>

                </thead>
                <tbody>
                    
                <?php

                // getting the page number and serial number

                $page = 1;

                if(isset($_GET['page'])){

                    if(is_numeric($_GET['page'])){

                        $page = $_GET['page'];

                        if($page != 1){

                            $page = $page * 10;

                            $page = $page - 9;
                        
                        }

                        }else{

                            $page = 1;
                        }

                    }else{

                        $page = 1;
                    }


                // getting status and deatails of users

                    foreach ($users as $user) { ;

                        if($user->email_verified_at == ''){

                            $status = "Pending";

                            $class= "warning";
                        
                        }else{

                            $status = "Confirm";

                            $class = "success";

                        }


                        if($user->accountType == 1){

                            $type = "Level A";

                        }elseif($user->accountType == 2){

                            $type = "Level B";

                        }elseif($user->accountType == 3){

                            $type = "Level C";                            

                        }


                        ?>


                  <tr>
                    <td><?php echo e($page); ?></td>
                
                    <td><?php echo e($user->email); ?></td>
                
                    <td><span class="<?php echo e($class); ?>"><?php echo e($status); ?></span></td>
                
                    <td><?php echo e($type); ?></td>
                
                    <td><?php echo e($user->created_at); ?></td>
                
                    <td><span data-toggle="modal" data-target="#myModal"><i class="fa fa-pencil"></i></span>&nbsp&nbsp<span><i class="fa fa-trash" data-id="<?php echo e($user->id); ?>"></i></span></td>
                
                  </tr>
                
                    <?php $page++;  }?>
                
                </tbody>

              </table>
                                      <?php echo e($users->links()); ?>


             </div>
        
    </div>

</div>
    

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="js/script.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/home.blade.php */ ?>