<?php $__env->startSection('title'); ?>

Lottery | Dashboard | 2D Betform

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="card-header"><h2>Form</h2></div>

            <p>2D bet form for different level users.</p>

           <?php if(!isset($errors)): ?> 
                <?php echo e($errors); ?>


            <?php endif; ?>

            <?php if($errors->any()): ?>
              
              <div class="alert alert-danger">
                
                <ul>
              
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <li><?php echo e($error); ?></li>
                
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </ul>
              
              </div>
          
            <?php endif; ?>

            <?php if(isset( $data )): ?>

            <button class="btn btn-primary" id="pdf">Print</button>

              <table class="table table-hover table-respponsive" id="example">
              
                <thead>
              
                  <tr>
              
                    <th>2D</th>
              
                    <th>USD</th>
              
                    <th>KHR</th>
              
                    <th>PO</th>
              
                  </tr>
              
                </thead>
              
              <tbody>
              
  <?php

                
                $datacount = count($data);


                if($datacount == 1){
              
              ?>

               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
              
                    <td><?php echo e($bat->d2_value); ?></td>
              
                    <td><?php echo e($bat->usd_value); ?></td>
              
                    <td><?php echo e($bat->khr_value); ?></td>

                    <td><?php if(isset( $bat->checkbox_value )): ?>

                      <?php echo e($bat->checkbox_value); ?>


                      <?php elseif(isset( $bat->level_value )): ?>

                      <?php echo e($bat->level_value); ?>


                      <?php endif; ?>

                    </td>
                <td><?php echo e($bat->created_at); ?></td>
              
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                
                <td>Total</td>

                <td>

                  <?php $countcheckboxval = 0; $batval = 0;?>
                
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if(isset( $bat->radio_value )): ?>

                    <?php if( $bat->radio_value == '5OD' || $bat->radio_value == '5S' ): ?>  
                     
                      <?php if(isset( $bat->checkbox_value )): ?> 

                        $countcheckboxval = count($checkboxval);

                        $batval = $batval + $bat->usd_value;
                      
                        <?php echo e($countcheckboxval * $batval * 5); ?>

                    
                      <?php if($bat->level_value == 'l23' ): ?>

                        <?php echo e($bat->usd_value * 5 * 23); ?>


                      <?php elseif( $bat->level_value == 'l29' ): ?>
                      
                        <?php echo e($bat->usd_value * 5 * 29); ?>


                      <?php endif; ?>

                    <?php endif; ?>

                    <?php elseif( $bat->radio_value == '10S' ): ?>

                      <?php if(isset( $bat->checkbox_value )): ?> 

                        <?php echo e(count($checkboxvalue) * $bat->usd_value * 10); ?>


                    <?php endif; ?>

                  <?php endif; ?>

                  <?php elseif(isset( $bat->level_value )): ?>

                    <?php if($bat->level_value == 'l23' ): ?>

                      <?php echo e($bat->usd_value * 23); ?>


                    <?php elseif( $bat->level_value == 'l29' ): ?>
                      
                      <?php echo e($bat->usd_value * 29); ?>



                    <?php endif; ?>

                  <?php elseif( !isset( $bat->radio_value )): ?>

                    <?php echo e(count($checkboxvalue) * $bat->usd_value); ?>

                  
                  <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </td>
                <td></td>
                <td><?php echo e($bat->created_at); ?></td>

              </tr>
              <?php }else{

              ?>


              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php for( $i = 0; $i < count($bat); $i++): ?>
            
                  <tr>
              
                    <td><?php echo e($bat[$i]->d2_value); ?></td>
              
                    <td><?php echo e($bat[$i]->usd_value); ?></td>
              
                    <td><?php echo e($bat[$i]->khr_value); ?></td>

                    <td><?php if(isset( $bat[$i]->checkbox_value )): ?>

                      <?php echo e($bat[$i]->checkbox_value); ?>


                      <?php $checkboxval = count($checkboxvalue);?>

                      <?php elseif(isset( $bat[$i]->level_value )): ?>

                      <?php echo e($bat[$i]->level_value); ?>


                      <?php 

                      if($bat[$i]->level_value == 'l23'){

                        $checkboxval = 23;
                        
                      }elseif($bat[$i]->level_value == 'l29'){

                        $checkboxval = 29;

                      };?>

                      <?php endif; ?>

                    </td>

              
                <td><?php echo e($bat[$i]->created_at); ?></td>
              
                  </tr>
                  <?php endfor; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                
                <td>Total</td>
               
                <td>

                  <?php $countcheckboxval = 0; $batval = 0;?>
                  
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php for( $i = 0; $i < count($bat); $i++): ?>
                  
                  <?php if(isset( $bat[$i]->radio_value )): ?>

                    <?php if( $bat[$i]->radio_value == '5OD' || $bat[$i]->radio_value == '5S' ): ?>  

                      <?php if(isset( $bat[$i]->checkbox_value )): ?> 

                       <?php  $countcheckboxval = count($checkboxvalue);?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value  * $countcheckboxval );?>
                      
                      <?php elseif(isset( $bat[$i]->level_value )): ?>
                        
                        <?php if($bat[$i]->level_value == 'l23' ): ?>

                        <?php $batval = $batval + ( $bat[$i]->usd_value * 23 ) ;?>

                      <?php elseif( $bat[$i]->level_value == 'l29' ): ?>
                      
                        <?php $batval = $batval + ( $bat[$i]->usd_value * 29 ) ;?>

                      <?php endif; ?>
                    <?php endif; ?>

                    <?php elseif( $bat[$i]->radio_value == '10S' ): ?>

                      <?php if(isset( $bat[$i]->checkbox_value )): ?> 

                    <?php  $countcheckboxval = count($checkboxvalue);?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value  * $countcheckboxval );?>

                  <?php elseif(isset( $bat[$i]->level_value )): ?>

                    <?php if($bat[$i]->level_value == 'l23' ): ?>

                      <?php $batval = $batval + ( $bat[$i]->usd_value * 23 ) ;?>

                    <?php elseif( $bat[$i]->level_value == 'l29' ): ?>
                      
                      <?php $batval = $batval + ( $bat[$i]->usd_value * 29 ) ;?>

                    <?php endif; ?>  


                  <?php elseif( !isset( $bat[$i]->radio_value )): ?>

                    <?php $batval = count($checkboxvalue) * $bat->usd_value;?>
                                      
                  <?php endif; ?>
                  <?php endif; ?>
                  <?php endif; ?>

                <?php endfor; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $batval;?>
                <?php } ?> 
                </td>
                <td></td>
               

              </tr>
              
                </tbody>
              
              </table>
              
            <?php endif; ?>


            <?php if(isset($successmsg)): ?>

              <div class="alert alert-success"> <?php echo e($successmsg); ?></div>

            <?php endif; ?>
            
            <?php if( Session::has( 'errormessage' )): ?>

              <div class="alert alert-success"> <?php echo e(Session::get( 'errormessage' )); ?></div>

            <?php endif; ?>

            <button type="submit" class="btn btn-primary" id="add">+ Add More Fields</button>

            <form action="<?php echo url('/');?>/dashboard/2d-betform" method="POST">
              
              <?php echo csrf_field(); ?>

              <input type="hidden" id="lastlevel" value="1" />

              <div class="first-line">

                <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div>

                <div class="form-group">
                
                  <label for="2d">2D:</label>
                
                  <input type="text" id="2d1" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed">
                
                </div>

                 <div class="form-group">
                
                  <label for="usd">USD:</label>
                
                  <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) ">
                
                </div>

                <div class="form-group">
                
                  <label for="khr">KHR:</label>
                
                  <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )">
                
                </div>

              </div>

              <div class="radio">

                <label class="radio-inline"><input type="radio" name="optradio" value="5OD">5 OD</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="5S">5 S</label>
              
                <label class="radio-inline"><input type="radio" name="optradio" value="10S">10 S</label>

              </div>

              <div class="checkbox">
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="A" name="checkbox[]">A</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="B" name="checkbox[]">B</label>
                
                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="C" name="checkbox[]">C</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="D" name="checkbox[]">D</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="H" name="checkbox[]">H</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="I" name="checkbox[]">I</label>

                <label class="checkbox-inline"><input type="checkbox" class="singleCheckbox" value="N" name="checkbox[]">N</label>

              </div>

               <input type="hidden" value="" id="checkbox-val">

              <div class="checkbox">
                
                <label class="checkbox-inline"><input type="checkbox" id="l23" value="l23" class="checkLevel" name="level_checkbox[]">L 23</label>
                
                <label class="checkbox-inline"><input type="checkbox" id="l29" value="l29" class="checkLevel" name="level_checkbox[]">L 29</label>
                
              </div>

              <button type="submit" class="btn btn-default">Submit</button>
            
            </form>            

            <br/>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="<?php echo url('/');?>/js/script.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>

<script src="<?php echo url('/');?>/js/tableHTMLExport.js"></script>

<script>
  
  $(document).on('click', '#pdf' ,function(){
    $("#example").tableHTMLExport({type:'pdf',filename:'report.pdf'});
  });

</script>

<script type="text/javascript">
  
  $(document).ready(function(){

    $('#add').click(function(event){

      var level = $('#lastlevel').val();

      console.log("level is " + level);

      var txt2d = $('#2d'+level).val();

      var usd = $('#usd'+level).val();

      var khr = $('#khr'+level).val();

      console.log("2d value is " + txt2d);

      if( txt2d != '' && txt2d.length == 2 &&(usd != '' || khr != '')){

        var radioValue = $("input[name='optradio']:checked").val();
        
        if(radioValue){
        
          console.log("Your are a - " + radioValue);
          
          txt2d = parseInt(txt2d);

          if(radioValue == '5OD'){

            if(level > '4'){

               swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 2;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>');

            }

          }else if(radioValue == '5S'){

            if(level > '4'){

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{

              txt2d = txt2d + 1;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 

            }

          }else if(radioValue == '10S'){

             if(level == 10){

            console.log('matched');

              swal("Oops!", "You cannot add more fields!", "warning");

            }else{
              console.log('not matched');

              txt2d = txt2d + 1;

              level ++;

              $('#lastlevel').val(level); 

              $('.first-line').append('<div class="card-header"><h3 id="level" data-level="'+level+'">Level '+level+'</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d'+level+'" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+txt2d+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd'+level+'" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usd+'"/> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr'+level+'" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khr+'"/></div>'); 
    
            }

          }else{
            // console.log('nothing matched');
            swal("Oops!", "Please handle checkbox validation error!", "warning");
            // nothing goes here all checkbox conditions have been checked above
          }

          }else{

            swal("Oops!", "Please select any of the radiobutton!", "warning");

          }  

        }else{

          swal("Oops!", "Please input all fields before adding extra fields!", "warning");
       
        }

    });

  });

  $(document).on('click', '.radio-inline', function(){

     var d2val = $('#2d1').val();

      var usdval = $('#usd1').val();

      var khrval = $('#khr1').val();

      // console.log(d3val);

      // console.log(usdval);

      // console.log(khrval);

      $('#lastlevel').val('1');

      $('.first-line').html(' <div class="card-header"><h3 id="level" data-level="1">Level 1</h3></div><div class="form-group"> <label for="2d">2D:</label> <input type="text" id="2d1" class="form-control 2d" name="txt2d[]" placeholder="Only 2 digit number between 00-99 allowed" value="'+d2val+'"> </div><div class="form-group"> <label for="usd">USD:</label> <input type="text" id="usd1" class="form-control usd" name="usd[]" placeholder="Only 6 digit float number is allowed ( eg 1.25 or 253.75 ) " value="'+usdval+'"> </div><div class="form-group"> <label for="khr">KHR:</label> <input type="text" id="khr1" class="form-control khr" name="khr[]" placeholder="Only 6 digit integer is allowed ( eg 20 or 35 or 1500 )" value="'+khrval+'"> </div>');

    });


  $(document).on('keypress', '.2d', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

       if (event.which > 47 &&  event.which < 58  && targetValue.length < 2) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if (result < 0 || result > 99) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }
       
       else {
       
           event.preventDefault();
       
       }


    });

  $(document).on('keypress', '.usd', function(event){

        var data = $(this).attr('id');

        var targetValue = $(this).val();

        console.log(targetValue);

        console.log(event.keyCode);

        if (event.which ===8 || event.which === 13 || event.which === 37 || event.which === 39 || event.which === 46) { 
          return;

        }

        // if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
          
        //   event.preventDefault();
        
        // }else{
        
        if (event.which > 47 &&  event.which < 58  && targetValue.length < 6) {
        
          var c = String.fromCharCode(event.which);

          var val = parseInt(c);
        
          var textVal = parseInt(targetValue || "0");
        
          var result = textVal + val;

          if (result < 0 || result > 99) {
        
             event.preventDefault();
        
          }

          if (targetValue === "0") {
        
            $(this).val(val);
        
            event.preventDefault();
        
          }
       
       }

       
       else {
       
           event.preventDefault();
       
       }

    });

  $(document).on('click', '.checkLevel', function(){

 var checked = $(this).prop('checked');

    if(checked){

      var checkboxValue = $(this).val();

      $('#checkbox-val').val('upper');

      console.log(checkboxValue);

      if(checkboxValue == 'l23'){

        $('#l29').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }else if(checkboxValue == 'l29'){

        $('#l23').prop('checked', false);

        $('.singleCheckbox').prop('checked', false);

      }

    }else{

      console.log('checkbox unclicked');

      $('#checkbox-val').val('lower');

    }

  });


  $(document).on('click', '.singleCheckbox', function(){

     var checked = $(this).prop('checked');

    if(checked){

        $('#checkbox-val').val('upper');
        
        $('#l23').prop('checked', false);

        $('#l29').prop('checked', false);

    }else{

        console.log('checkbox unclicked');

        $('#checkbox-val').val('lower');

        console.log($('#checkbox-val').val());

    }

  });

  $(document).on('click', '.btn-default', function(event){

    // alert('asasas');

    var txt2d = $('#2d1').val();

    var usd = $('#usd1').val();

    var khr = $('#khr1').val();

    console.log(txt2d);

    console.log(usd);

    console.log(khr);

 if(txt2d != "" && txt2d.length == 2){

      if((usd != "") || (khr != "" && khr.length == 2)){

        var status = $('#checkbox-val').val();

          if(status == 'upper'){

          // event.preventDefault();
          
          // swal("Oops!", "Checkbox checked!", "warning");

        }else if(status == 'lower'){

          event.preventDefault();

          console.log('status is false but still it is showing this message');
          
          swal("Oops!", "None of the checkbox is checked!", "warning");

        }else{

          event.preventDefault();

          swal("Oops!", "Please check any of the checkboxes before moving further.", "warning");          

        }

        // $('#3dform').submit();

          // event.preventDefault();
          
          // swal("Oops!", "Condition satisfied!", "warning"); 

      }else{

        event.preventDefault();

        swal("Oops!", "Please input either USD or KHR in valid format!", "warning");
      }

    }else{

      event.preventDefault();
           
      swal("Oops!", "Please input 3D field with minimum 3 digits between 101-999 before moving forward!", "warning");

    }

  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/2d-betform.blade.php */ ?>