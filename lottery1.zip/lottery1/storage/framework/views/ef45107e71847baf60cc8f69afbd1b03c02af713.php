<?php $__env->startSection('title'); ?>

Lottery | Dashboard

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="card-header"><h2>Add User</h2></div>

            <p>Add users with different parameters to allow them to trade.</p>

            <?php if( Session::has( 'errormsg' )): ?>

              <div class="alert alert-success"> <?php echo e(Session::get( 'successmsg' )); ?></div>

            <?php endif; ?>
            
            <?php if( Session::has( 'errormsg' )): ?>

              <div class="alert alert-success"> <?php echo e(Session::get( 'errormsg' )); ?></div>

            <?php endif; ?>

            <form action="<?php echo url('/');?>/dashboard/add-users" method="POST">
              
              <?php echo csrf_field(); ?>

              <div class="form-group">
              
                <label for="username">Username:</label>
              
                <input type="text" class="form-control" id="username" name="name">
              
              </div>

              <div class="form-group">
              
                <label for="fullname">Full Name:</label>
              
                <input type="text" class="form-control" id="fullname" name="fullname">
              
              </div>

              <div class="form-group">
              
                <label for="email">Email address:</label>
              
                <input type="email" class="form-control" id="email" name="email">
              
              </div>
              
              <div class="form-group">
              
                <label for="pwd">Password:</label>
              
                <input type="password" class="form-control" id="pwd" name="password">
              
              </div>

              <div class="form-group">
    
                <label for="userlevel">Select User Level:</label>
                    
                    <select class="form-control" id="userlevel" name="userlevel">
    
                        <option value="1">Level A</option>
    
                    </select>
               
               </div>

               <div class="form-group">
              
                <label for="balanceusd">Balance USD:</label>
              
                <input type="text" class="form-control" id="balanceusd" name="balanceUSD">
              
              </div>

              <div class="form-group">
              
                <label for="balancekhr">Balanace KHR:</label>
              
                <input type="text" class="form-control" id="balancekhr" name="balanceKHR">
              
              </div>

              <div class="form-group">
              
                <label for="userpercent">User Percent:</label>
              
                <input type="text" class="form-control" id="userpercent" name="userpercent">
              
              </div>

              <div class="form-group">
              
                <label for="phone">Phone:</label>
              
                <input type="text" class="form-control" id="phone" name="phone">
              
              </div>

              <div class="form-group">
              
                <label for="address">Address:</label>
              
                <input type="text" class="form-control" id="address" name="address">
              
              </div>
              
              <button type="submit" class="btn btn-default">Submit</button>
            
            </form>            

            <br/>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="js/script.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/add-users.blade.php */ ?>