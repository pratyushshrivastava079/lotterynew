<?php $__env->startSection('title'); ?>

Lottery | Dashboard

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
            <div class="card-header"><strong><h2>User List</h2></strong></div>

              <p>The list consists of all the users on the website.</p>   

               <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>

              <form id="addsubuser" method="POST" action="<?php echo url('/');?>/dashboard/adduserlevel">

                <?php if($errors->any()): ?>
                  
                  <div class="alert alert-danger">
                  
                    <ul>
                  
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                        <li><?php echo e($error); ?></li>
                  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                    </ul>
                  
                  </div>
                
                <?php endif; ?>
              
              <?php echo csrf_field(); ?>

              <div class="form-group">
              
                <label for="username">Username:</label>
              
                <input type="text" class="form-control" id="addusername" name="name">
              
              </div>

              <div class="form-group">
              
                <label for="fullname">Full Name:</label>
              
                <input type="text" class="form-control" id="addfullname" name="fullname">
              
              </div>

              <div class="form-group">
              
                <label for="email">Parent Username:</label>
              
                <input type="hidden" class="form-control" id="addparentUsername" name="parentUsername" value="<?php echo e($user->id); ?>">

                <p><button class="btn btn-primary"><?php echo e($user->name); ?></button></p>
              
              </div>
              
              <div class="form-group">
              
                <label for="pwd">Password:</label>
              
                <input type="password" class="form-control" id="addpassword" name="password">
              
              </div>

              <div class="form-group">
    
                <label for="userlevel">Select User Level:</label>
                    
                    <select class="form-control" id="adduserlevel" name="userlevel">

                       <?php if( $user->accountType == 1 ): ?>
    
                        <option value="2">Level B</option>

                        <?php elseif( $user->accountType == 2 ): ?>
    
                        <option value="3">Level C</option>

                        <?php elseif( $user->accountType == 3 ): ?>
    
                        <option value="4">Level D</option>

                        <?php endif; ?>
    
                    </select>
               
               </div>

              <div class="form-group">
              
                <label for="phone">Phone:</label>
              
                <input type="text" class="form-control" id="addphone" name="phone">
              
              </div>

              <div class="form-group">
              
                <label for="address">Address:</label>
              
                <input type="text" class="form-control" id="addaddress" name="address">
              
              </div>
              
              <button type="submit" class="btn btn-primary" id="btnsubuser">Submit</button>
            
            </form>         
                                      


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript" src="<?php echo url('/');?>js/script.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/lottery/resources/views/adduserlevel.blade.php */ ?>